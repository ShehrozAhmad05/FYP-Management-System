﻿namespace DBProjectA
{
    partial class ManageEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV = new System.Windows.Forms.DataGridView();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.lblViewLogo = new System.Windows.Forms.Label();
            this.UpdateBtn = new System.Windows.Forms.Button();
            this.txtTotalWeightage = new System.Windows.Forms.TextBox();
            this.lblTotalWeightage = new System.Windows.Forms.Label();
            this.txtTotalMarks = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblTotalMarks = new System.Windows.Forms.Label();
            this.lblEName = new System.Windows.Forms.Label();
            this.Selectbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV
            // 
            this.DGV.AllowUserToAddRows = false;
            this.DGV.AllowUserToDeleteRows = false;
            this.DGV.AllowUserToResizeRows = false;
            this.DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV.BackgroundColor = System.Drawing.Color.LightCyan;
            this.DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV.ColumnHeadersHeight = 22;
            this.DGV.EnableHeadersVisualStyles = false;
            this.DGV.Location = new System.Drawing.Point(20, 86);
            this.DGV.Name = "DGV";
            this.DGV.ReadOnly = true;
            this.DGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV.RowHeadersVisible = false;
            this.DGV.RowHeadersWidth = 51;
            this.DGV.RowTemplate.Height = 24;
            this.DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV.Size = new System.Drawing.Size(475, 489);
            this.DGV.TabIndex = 72;
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(1143, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 74;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // lblViewLogo
            // 
            this.lblViewLogo.AutoSize = true;
            this.lblViewLogo.BackColor = System.Drawing.Color.White;
            this.lblViewLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewLogo.Location = new System.Drawing.Point(13, 9);
            this.lblViewLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblViewLogo.Name = "lblViewLogo";
            this.lblViewLogo.Size = new System.Drawing.Size(276, 40);
            this.lblViewLogo.TabIndex = 73;
            this.lblViewLogo.Text = "MANAGE EVALUATION";
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.UpdateBtn.Location = new System.Drawing.Point(874, 452);
            this.UpdateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(123, 47);
            this.UpdateBtn.TabIndex = 102;
            this.UpdateBtn.Text = "Update";
            this.UpdateBtn.UseVisualStyleBackColor = true;
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // txtTotalWeightage
            // 
            this.txtTotalWeightage.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtTotalWeightage.Location = new System.Drawing.Point(740, 378);
            this.txtTotalWeightage.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalWeightage.Name = "txtTotalWeightage";
            this.txtTotalWeightage.Size = new System.Drawing.Size(257, 33);
            this.txtTotalWeightage.TabIndex = 101;
            // 
            // lblTotalWeightage
            // 
            this.lblTotalWeightage.AutoSize = true;
            this.lblTotalWeightage.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblTotalWeightage.Location = new System.Drawing.Point(736, 351);
            this.lblTotalWeightage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalWeightage.Name = "lblTotalWeightage";
            this.lblTotalWeightage.Size = new System.Drawing.Size(170, 23);
            this.lblTotalWeightage.TabIndex = 100;
            this.lblTotalWeightage.Text = "Total Weightage";
            // 
            // txtTotalMarks
            // 
            this.txtTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtTotalMarks.Location = new System.Drawing.Point(740, 271);
            this.txtTotalMarks.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalMarks.Name = "txtTotalMarks";
            this.txtTotalMarks.Size = new System.Drawing.Size(257, 33);
            this.txtTotalMarks.TabIndex = 99;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtName.Location = new System.Drawing.Point(740, 162);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(257, 33);
            this.txtName.TabIndex = 98;
            // 
            // lblTotalMarks
            // 
            this.lblTotalMarks.AutoSize = true;
            this.lblTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblTotalMarks.Location = new System.Drawing.Point(735, 241);
            this.lblTotalMarks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalMarks.Name = "lblTotalMarks";
            this.lblTotalMarks.Size = new System.Drawing.Size(123, 23);
            this.lblTotalMarks.TabIndex = 97;
            this.lblTotalMarks.Text = "Total Marks";
            // 
            // lblEName
            // 
            this.lblEName.AutoSize = true;
            this.lblEName.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEName.Location = new System.Drawing.Point(735, 132);
            this.lblEName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEName.Name = "lblEName";
            this.lblEName.Size = new System.Drawing.Size(66, 23);
            this.lblEName.TabIndex = 96;
            this.lblEName.Text = "Name";
            // 
            // Selectbtn
            // 
            this.Selectbtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.Selectbtn.Location = new System.Drawing.Point(372, 582);
            this.Selectbtn.Margin = new System.Windows.Forms.Padding(4);
            this.Selectbtn.Name = "Selectbtn";
            this.Selectbtn.Size = new System.Drawing.Size(123, 47);
            this.Selectbtn.TabIndex = 103;
            this.Selectbtn.Text = "Select";
            this.Selectbtn.UseVisualStyleBackColor = true;
            this.Selectbtn.Click += new System.EventHandler(this.Selectbtn_Click);
            // 
            // ManageEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1197, 691);
            this.Controls.Add(this.Selectbtn);
            this.Controls.Add(this.UpdateBtn);
            this.Controls.Add(this.txtTotalWeightage);
            this.Controls.Add(this.lblTotalWeightage);
            this.Controls.Add(this.txtTotalMarks);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblTotalMarks);
            this.Controls.Add(this.lblEName);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblViewLogo);
            this.Controls.Add(this.DGV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageEvaluation";
            this.Text = "ManageEvaluation";
            this.Load += new System.EventHandler(this.ManageEvaluation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblViewLogo;
        private System.Windows.Forms.Button UpdateBtn;
        private System.Windows.Forms.TextBox txtTotalWeightage;
        private System.Windows.Forms.Label lblTotalWeightage;
        private System.Windows.Forms.TextBox txtTotalMarks;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblTotalMarks;
        private System.Windows.Forms.Label lblEName;
        private System.Windows.Forms.Button Selectbtn;
    }
}