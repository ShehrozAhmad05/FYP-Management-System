﻿namespace DBProjectA
{
    partial class CreateEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddAdvLogo = new System.Windows.Forms.Label();
            this.txtTotalWeightage = new System.Windows.Forms.TextBox();
            this.lblTotalWeightage = new System.Windows.Forms.Label();
            this.txtTotalMarks = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblTotalMarks = new System.Windows.Forms.Label();
            this.lblEName = new System.Windows.Forms.Label();
            this.CreateBtn = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAddAdvLogo
            // 
            this.lblAddAdvLogo.AutoSize = true;
            this.lblAddAdvLogo.BackColor = System.Drawing.Color.White;
            this.lblAddAdvLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddAdvLogo.Location = new System.Drawing.Point(13, 9);
            this.lblAddAdvLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddAdvLogo.Name = "lblAddAdvLogo";
            this.lblAddAdvLogo.Size = new System.Drawing.Size(268, 40);
            this.lblAddAdvLogo.TabIndex = 76;
            this.lblAddAdvLogo.Text = "CREATE EVALUATION";
            // 
            // txtTotalWeightage
            // 
            this.txtTotalWeightage.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtTotalWeightage.Location = new System.Drawing.Point(307, 368);
            this.txtTotalWeightage.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalWeightage.Name = "txtTotalWeightage";
            this.txtTotalWeightage.Size = new System.Drawing.Size(257, 33);
            this.txtTotalWeightage.TabIndex = 90;
            // 
            // lblTotalWeightage
            // 
            this.lblTotalWeightage.AutoSize = true;
            this.lblTotalWeightage.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblTotalWeightage.Location = new System.Drawing.Point(303, 341);
            this.lblTotalWeightage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalWeightage.Name = "lblTotalWeightage";
            this.lblTotalWeightage.Size = new System.Drawing.Size(170, 23);
            this.lblTotalWeightage.TabIndex = 89;
            this.lblTotalWeightage.Text = "Total Weightage";
            // 
            // txtTotalMarks
            // 
            this.txtTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtTotalMarks.Location = new System.Drawing.Point(307, 261);
            this.txtTotalMarks.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalMarks.Name = "txtTotalMarks";
            this.txtTotalMarks.Size = new System.Drawing.Size(257, 33);
            this.txtTotalMarks.TabIndex = 88;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtName.Location = new System.Drawing.Point(307, 152);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(257, 33);
            this.txtName.TabIndex = 87;
            // 
            // lblTotalMarks
            // 
            this.lblTotalMarks.AutoSize = true;
            this.lblTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblTotalMarks.Location = new System.Drawing.Point(302, 231);
            this.lblTotalMarks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalMarks.Name = "lblTotalMarks";
            this.lblTotalMarks.Size = new System.Drawing.Size(123, 23);
            this.lblTotalMarks.TabIndex = 86;
            this.lblTotalMarks.Text = "Total Marks";
            // 
            // lblEName
            // 
            this.lblEName.AutoSize = true;
            this.lblEName.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEName.Location = new System.Drawing.Point(302, 122);
            this.lblEName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEName.Name = "lblEName";
            this.lblEName.Size = new System.Drawing.Size(66, 23);
            this.lblEName.TabIndex = 85;
            this.lblEName.Text = "Name";
            // 
            // CreateBtn
            // 
            this.CreateBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.CreateBtn.Location = new System.Drawing.Point(418, 445);
            this.CreateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.CreateBtn.Name = "CreateBtn";
            this.CreateBtn.Size = new System.Drawing.Size(146, 49);
            this.CreateBtn.TabIndex = 95;
            this.CreateBtn.Text = "Create";
            this.CreateBtn.UseVisualStyleBackColor = true;
            this.CreateBtn.Click += new System.EventHandler(this.CreateBtn_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(812, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 77;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // CreateEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(866, 615);
            this.Controls.Add(this.CreateBtn);
            this.Controls.Add(this.txtTotalWeightage);
            this.Controls.Add(this.lblTotalWeightage);
            this.Controls.Add(this.txtTotalMarks);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblTotalMarks);
            this.Controls.Add(this.lblEName);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblAddAdvLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CreateEvaluation";
            this.Text = "CreateEvaluation";
            this.Load += new System.EventHandler(this.CreateEvaluation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblAddAdvLogo;
        private System.Windows.Forms.TextBox txtTotalWeightage;
        private System.Windows.Forms.Label lblTotalWeightage;
        private System.Windows.Forms.TextBox txtTotalMarks;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblTotalMarks;
        private System.Windows.Forms.Label lblEName;
        private System.Windows.Forms.Button CreateBtn;
    }
}