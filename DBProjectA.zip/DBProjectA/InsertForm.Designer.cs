﻿namespace DBProjectA
{
    partial class InsertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Insert = new System.Windows.Forms.Button();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.RegistrationNo = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.Gender = new System.Windows.Forms.Label();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblAddStdLogo = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // Insert
            // 
            this.Insert.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.Insert.Location = new System.Drawing.Point(366, 529);
            this.Insert.Margin = new System.Windows.Forms.Padding(4);
            this.Insert.Name = "Insert";
            this.Insert.Size = new System.Drawing.Size(126, 49);
            this.Insert.TabIndex = 25;
            this.Insert.Text = "Add";
            this.Insert.UseVisualStyleBackColor = true;
            this.Insert.Click += new System.EventHandler(this.Insert_Click);
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtLastName.Location = new System.Drawing.Point(469, 157);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(257, 33);
            this.txtLastName.TabIndex = 43;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtFirstName.Location = new System.Drawing.Point(116, 157);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(257, 33);
            this.txtFirstName.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.label1.Location = new System.Drawing.Point(464, 127);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 23);
            this.label1.TabIndex = 41;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(111, 127);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 23);
            this.label2.TabIndex = 40;
            this.label2.Text = "First Name";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtContact.Location = new System.Drawing.Point(115, 252);
            this.txtContact.Margin = new System.Windows.Forms.Padding(4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(257, 33);
            this.txtContact.TabIndex = 49;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtEmail.Location = new System.Drawing.Point(469, 252);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(257, 33);
            this.txtEmail.TabIndex = 48;
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Contact.Location = new System.Drawing.Point(111, 225);
            this.Contact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(86, 23);
            this.Contact.TabIndex = 47;
            this.Contact.Text = "Contact";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Cursor = System.Windows.Forms.Cursors.Default;
            this.Email.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Email.Location = new System.Drawing.Point(464, 222);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(63, 23);
            this.Email.TabIndex = 46;
            this.Email.Text = "Email";
            // 
            // txtRegNo
            // 
            this.txtRegNo.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtRegNo.Location = new System.Drawing.Point(115, 351);
            this.txtRegNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.Size = new System.Drawing.Size(257, 33);
            this.txtRegNo.TabIndex = 51;
            // 
            // RegistrationNo
            // 
            this.RegistrationNo.AutoSize = true;
            this.RegistrationNo.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.RegistrationNo.Location = new System.Drawing.Point(110, 321);
            this.RegistrationNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.RegistrationNo.Name = "RegistrationNo";
            this.RegistrationNo.Size = new System.Drawing.Size(163, 23);
            this.RegistrationNo.TabIndex = 50;
            this.RegistrationNo.Text = "Registration No";
            // 
            // cmbGender
            // 
            this.cmbGender.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(467, 351);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(259, 33);
            this.cmbGender.TabIndex = 54;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Cursor = System.Windows.Forms.Cursors.Default;
            this.Gender.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Gender.Location = new System.Drawing.Point(465, 325);
            this.Gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(82, 23);
            this.Gender.TabIndex = 53;
            this.Gender.Text = "Gender";
            this.Gender.Click += new System.EventHandler(this.Gender_Click);
            // 
            // dtDOB
            // 
            this.dtDOB.CalendarFont = new System.Drawing.Font("Nirmala UI", 14.25F);
            this.dtDOB.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtDOB.Font = new System.Drawing.Font("Nirmala UI", 13F);
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDOB.Location = new System.Drawing.Point(297, 453);
            this.dtDOB.Margin = new System.Windows.Forms.Padding(4);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(257, 36);
            this.dtDOB.TabIndex = 56;
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblDOB.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblDOB.Location = new System.Drawing.Point(292, 424);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(139, 23);
            this.lblDOB.TabIndex = 55;
            this.lblDOB.Text = "Date Of Birth";
            // 
            // lblAddStdLogo
            // 
            this.lblAddStdLogo.AutoSize = true;
            this.lblAddStdLogo.BackColor = System.Drawing.Color.White;
            this.lblAddStdLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddStdLogo.Location = new System.Drawing.Point(13, 9);
            this.lblAddStdLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddStdLogo.Name = "lblAddStdLogo";
            this.lblAddStdLogo.Size = new System.Drawing.Size(185, 40);
            this.lblAddStdLogo.TabIndex = 57;
            this.lblAddStdLogo.Text = "ADD STUDENT";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(812, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 58;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // InsertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(866, 615);
            this.ControlBox = false;
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblAddStdLogo);
            this.Controls.Add(this.dtDOB);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.txtRegNo);
            this.Controls.Add(this.RegistrationNo);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Insert);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InsertForm";
            this.Text = "InsertForm";
            this.Load += new System.EventHandler(this.InsertForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Insert;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtRegNo;
        private System.Windows.Forms.Label RegistrationNo;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblAddStdLogo;
    }
}