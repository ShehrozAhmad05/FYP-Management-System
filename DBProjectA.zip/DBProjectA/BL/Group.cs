﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProjectA.BL
{
    public class Group
    {
        string id;
        string created_on;

        public Group(string created_on)
        {
            this.created_on = created_on;
        }

        public Group(string id, string created_on)
        {
            this.id = id;
            this.created_on = created_on;
        }
        public string Id { get => id; set => id = value; }
        public string Created_on { get => created_on; set => created_on = value; }
    }
}
