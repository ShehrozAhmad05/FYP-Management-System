﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProjectA.BL
{
    public class Advisor: Person
    {
        string designation;
        string salary;

        public Advisor(string firstName, string lastName, string contact, string email,
                            string dateOfBirth, string gender, string designation, string salary) : base(firstName, lastName, contact, email, dateOfBirth, gender)
        {
            this.Salary = salary;
            this.Designation = designation;
        }

        public Advisor(string id, string firstName, string lastName, string contact, string email,
                           string dateOfBirth, string gender, string designation, string salary) : base(id, firstName, lastName, contact, email, dateOfBirth, gender)
        {
            this.Salary = salary;
            this.Designation = designation;
        }

        public string Designation { get => designation; set => designation = value; }
        public string Salary { get => salary; set => salary = value; }
    }

}
