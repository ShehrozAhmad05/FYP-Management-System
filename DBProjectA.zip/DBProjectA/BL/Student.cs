﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProjectA.BL
{
    public class Student:Person
    {
        string registrationNumber;

        public Student(string firstName, string lastName, string contact, string email,
                        string dateOfBirth, string gender, string registrationNumber) : base(firstName, lastName, contact, email, dateOfBirth, gender)
        {
            this.RegistrationNumber = registrationNumber;
        }

        public Student(string id, string firstName, string lastName, string contact, string email,
                        string dateOfBirth, string gender, string registrationNumber) : base(id, firstName, lastName, contact, email, dateOfBirth, gender)
        {
            this.RegistrationNumber = registrationNumber;
        }

        public string RegistrationNumber { get => registrationNumber; set => registrationNumber = value; }
    }
}
