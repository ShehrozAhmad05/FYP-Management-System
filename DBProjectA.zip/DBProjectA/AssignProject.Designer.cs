﻿namespace DBProjectA
{
    partial class AssignProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewLogo = new System.Windows.Forms.Label();
            this.DGV_group = new System.Windows.Forms.DataGridView();
            this.DGV_project = new System.Windows.Forms.DataGridView();
            this.selectGrpbtn = new System.Windows.Forms.Button();
            this.selectprjbtn = new System.Windows.Forms.Button();
            this.selectadvisorbtn = new System.Windows.Forms.Button();
            this.cmbMainAdvisor = new System.Windows.Forms.ComboBox();
            this.lblMainAdvisor = new System.Windows.Forms.Label();
            this.cmbCoAdvisor = new System.Windows.Forms.ComboBox();
            this.lblCoAdvisor = new System.Windows.Forms.Label();
            this.cmbIndustryAdvisor = new System.Windows.Forms.ComboBox();
            this.lblIndAdvisor = new System.Windows.Forms.Label();
            this.btnAssignprj = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_group)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_project)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblViewLogo
            // 
            this.lblViewLogo.AutoSize = true;
            this.lblViewLogo.BackColor = System.Drawing.Color.White;
            this.lblViewLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewLogo.Location = new System.Drawing.Point(13, 9);
            this.lblViewLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblViewLogo.Name = "lblViewLogo";
            this.lblViewLogo.Size = new System.Drawing.Size(232, 40);
            this.lblViewLogo.TabIndex = 68;
            this.lblViewLogo.Text = "ASSIGN PROJECTS";
            // 
            // DGV_group
            // 
            this.DGV_group.AllowUserToAddRows = false;
            this.DGV_group.AllowUserToDeleteRows = false;
            this.DGV_group.AllowUserToResizeRows = false;
            this.DGV_group.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_group.BackgroundColor = System.Drawing.Color.LightCyan;
            this.DGV_group.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV_group.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_group.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_group.ColumnHeadersHeight = 22;
            this.DGV_group.EnableHeadersVisualStyles = false;
            this.DGV_group.Location = new System.Drawing.Point(20, 82);
            this.DGV_group.Name = "DGV_group";
            this.DGV_group.ReadOnly = true;
            this.DGV_group.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_group.RowHeadersVisible = false;
            this.DGV_group.RowHeadersWidth = 51;
            this.DGV_group.RowTemplate.Height = 24;
            this.DGV_group.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_group.Size = new System.Drawing.Size(515, 431);
            this.DGV_group.TabIndex = 70;
            // 
            // DGV_project
            // 
            this.DGV_project.AllowUserToAddRows = false;
            this.DGV_project.AllowUserToDeleteRows = false;
            this.DGV_project.AllowUserToResizeRows = false;
            this.DGV_project.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_project.BackgroundColor = System.Drawing.Color.LightCyan;
            this.DGV_project.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV_project.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_project.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_project.ColumnHeadersHeight = 22;
            this.DGV_project.EnableHeadersVisualStyles = false;
            this.DGV_project.Location = new System.Drawing.Point(579, 82);
            this.DGV_project.Name = "DGV_project";
            this.DGV_project.ReadOnly = true;
            this.DGV_project.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_project.RowHeadersVisible = false;
            this.DGV_project.RowHeadersWidth = 51;
            this.DGV_project.RowTemplate.Height = 24;
            this.DGV_project.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_project.Size = new System.Drawing.Size(638, 431);
            this.DGV_project.TabIndex = 71;
            // 
            // selectGrpbtn
            // 
            this.selectGrpbtn.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.selectGrpbtn.Location = new System.Drawing.Point(155, 520);
            this.selectGrpbtn.Margin = new System.Windows.Forms.Padding(4);
            this.selectGrpbtn.Name = "selectGrpbtn";
            this.selectGrpbtn.Size = new System.Drawing.Size(194, 49);
            this.selectGrpbtn.TabIndex = 72;
            this.selectGrpbtn.Text = "Select Group";
            this.selectGrpbtn.UseVisualStyleBackColor = true;
            this.selectGrpbtn.Click += new System.EventHandler(this.selectGrpbtn_Click);
            // 
            // selectprjbtn
            // 
            this.selectprjbtn.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.selectprjbtn.Location = new System.Drawing.Point(807, 520);
            this.selectprjbtn.Margin = new System.Windows.Forms.Padding(4);
            this.selectprjbtn.Name = "selectprjbtn";
            this.selectprjbtn.Size = new System.Drawing.Size(194, 49);
            this.selectprjbtn.TabIndex = 73;
            this.selectprjbtn.Text = "Select Project";
            this.selectprjbtn.UseVisualStyleBackColor = true;
            this.selectprjbtn.Click += new System.EventHandler(this.selectprjbtn_Click);
            // 
            // selectadvisorbtn
            // 
            this.selectadvisorbtn.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.selectadvisorbtn.Location = new System.Drawing.Point(17, 636);
            this.selectadvisorbtn.Margin = new System.Windows.Forms.Padding(4);
            this.selectadvisorbtn.Name = "selectadvisorbtn";
            this.selectadvisorbtn.Size = new System.Drawing.Size(181, 57);
            this.selectadvisorbtn.TabIndex = 74;
            this.selectadvisorbtn.Text = "Select Advisor";
            this.selectadvisorbtn.UseVisualStyleBackColor = true;
            this.selectadvisorbtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbMainAdvisor
            // 
            this.cmbMainAdvisor.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbMainAdvisor.FormattingEnabled = true;
            this.cmbMainAdvisor.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbMainAdvisor.Location = new System.Drawing.Point(237, 651);
            this.cmbMainAdvisor.Name = "cmbMainAdvisor";
            this.cmbMainAdvisor.Size = new System.Drawing.Size(259, 33);
            this.cmbMainAdvisor.TabIndex = 90;
            // 
            // lblMainAdvisor
            // 
            this.lblMainAdvisor.AutoSize = true;
            this.lblMainAdvisor.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblMainAdvisor.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblMainAdvisor.Location = new System.Drawing.Point(235, 625);
            this.lblMainAdvisor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMainAdvisor.Name = "lblMainAdvisor";
            this.lblMainAdvisor.Size = new System.Drawing.Size(136, 23);
            this.lblMainAdvisor.TabIndex = 89;
            this.lblMainAdvisor.Text = "Main Advisor";
            // 
            // cmbCoAdvisor
            // 
            this.cmbCoAdvisor.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbCoAdvisor.FormattingEnabled = true;
            this.cmbCoAdvisor.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbCoAdvisor.Location = new System.Drawing.Point(564, 651);
            this.cmbCoAdvisor.Name = "cmbCoAdvisor";
            this.cmbCoAdvisor.Size = new System.Drawing.Size(259, 33);
            this.cmbCoAdvisor.TabIndex = 92;
            // 
            // lblCoAdvisor
            // 
            this.lblCoAdvisor.AutoSize = true;
            this.lblCoAdvisor.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblCoAdvisor.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblCoAdvisor.Location = new System.Drawing.Point(562, 625);
            this.lblCoAdvisor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCoAdvisor.Name = "lblCoAdvisor";
            this.lblCoAdvisor.Size = new System.Drawing.Size(115, 23);
            this.lblCoAdvisor.TabIndex = 91;
            this.lblCoAdvisor.Text = "Co-Advisor";
            // 
            // cmbIndustryAdvisor
            // 
            this.cmbIndustryAdvisor.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbIndustryAdvisor.FormattingEnabled = true;
            this.cmbIndustryAdvisor.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbIndustryAdvisor.Location = new System.Drawing.Point(893, 651);
            this.cmbIndustryAdvisor.Name = "cmbIndustryAdvisor";
            this.cmbIndustryAdvisor.Size = new System.Drawing.Size(259, 33);
            this.cmbIndustryAdvisor.TabIndex = 94;
            // 
            // lblIndAdvisor
            // 
            this.lblIndAdvisor.AutoSize = true;
            this.lblIndAdvisor.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblIndAdvisor.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblIndAdvisor.Location = new System.Drawing.Point(891, 625);
            this.lblIndAdvisor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndAdvisor.Name = "lblIndAdvisor";
            this.lblIndAdvisor.Size = new System.Drawing.Size(171, 23);
            this.lblIndAdvisor.TabIndex = 93;
            this.lblIndAdvisor.Text = "Industry Advisor";
            // 
            // btnAssignprj
            // 
            this.btnAssignprj.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.btnAssignprj.Location = new System.Drawing.Point(1022, 731);
            this.btnAssignprj.Margin = new System.Windows.Forms.Padding(4);
            this.btnAssignprj.Name = "btnAssignprj";
            this.btnAssignprj.Size = new System.Drawing.Size(194, 49);
            this.btnAssignprj.TabIndex = 95;
            this.btnAssignprj.Text = "Assign Project";
            this.btnAssignprj.UseVisualStyleBackColor = true;
            this.btnAssignprj.Click += new System.EventHandler(this.btnAssignprj_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(1176, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 69;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // AssignProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1229, 793);
            this.Controls.Add(this.btnAssignprj);
            this.Controls.Add(this.cmbIndustryAdvisor);
            this.Controls.Add(this.lblIndAdvisor);
            this.Controls.Add(this.cmbCoAdvisor);
            this.Controls.Add(this.lblCoAdvisor);
            this.Controls.Add(this.cmbMainAdvisor);
            this.Controls.Add(this.lblMainAdvisor);
            this.Controls.Add(this.selectadvisorbtn);
            this.Controls.Add(this.selectprjbtn);
            this.Controls.Add(this.selectGrpbtn);
            this.Controls.Add(this.DGV_project);
            this.Controls.Add(this.DGV_group);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblViewLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AssignProject";
            this.Text = "AssignProject";
            this.Load += new System.EventHandler(this.AssignProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_group)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_project)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblViewLogo;
        private System.Windows.Forms.DataGridView DGV_group;
        private System.Windows.Forms.DataGridView DGV_project;
        private System.Windows.Forms.Button selectGrpbtn;
        private System.Windows.Forms.Button selectprjbtn;
        private System.Windows.Forms.Button selectadvisorbtn;
        private System.Windows.Forms.ComboBox cmbMainAdvisor;
        private System.Windows.Forms.Label lblMainAdvisor;
        private System.Windows.Forms.ComboBox cmbCoAdvisor;
        private System.Windows.Forms.Label lblCoAdvisor;
        private System.Windows.Forms.ComboBox cmbIndustryAdvisor;
        private System.Windows.Forms.Label lblIndAdvisor;
        private System.Windows.Forms.Button btnAssignprj;
    }
}