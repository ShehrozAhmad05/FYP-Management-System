﻿using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class SelectEvaluation : Form
    {
        ObtainedMarksEvaluation obtainedMarkEvaluation;
        GroupEvaluationDL groupEvaluationDL;
        string groupId;
        public SelectEvaluation(string groupId)
        {
            groupEvaluationDL = new GroupEvaluationDL();
            this.groupId = groupId;
            InitializeComponent();
        }

        private void SelectEvaluation_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!groupEvaluationDL.fetchPendingEvaluations(groupId))
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            DGV.DataSource = groupEvaluationDL.getList();

        }

        void bindData()
        {
            DGV.DataSource = null;
            if (!groupEvaluationDL.fetchPendingEvaluations(groupId))
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            DGV.DataSource = groupEvaluationDL.getList();
        }

        private void SelectBtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            obtainedMarkEvaluation = new ObtainedMarksEvaluation(groupId, DGV.Rows[rowIdx].Cells["Id"].Value.ToString(), DGV.Rows[rowIdx].Cells["TotalMarks"].Value.ToString(), DGV.Rows[rowIdx].Cells["TotalWeightage"].Value.ToString());
            obtainedMarkEvaluation.onSuccess += new EventHandler(onSuccessEvaluation);
            obtainedMarkEvaluation.ShowDialog();
        }

        private void onSuccessEvaluation(object sender, EventArgs e)
        {
            bindData();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.Show();
            this.Close();
        }
    }
}
