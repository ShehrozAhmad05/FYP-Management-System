﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class InsertForm : Form
    {
        StudentDL studentDL;
        public InsertForm()
        {
            studentDL = new StudentDL();
            InitializeComponent();
        }

        private void Department_Click(object sender, EventArgs e)
        {

        }

        private void SContact_Click(object sender, EventArgs e)
        {

        }

        private void InsertForm_Load(object sender, EventArgs e)
        {

        }

        private void Insert_Click(object sender, EventArgs e)
        {
            

            TextBox[] textBoxes = new TextBox[5];
            textBoxes[0] = txtFirstName;
            textBoxes[1] = txtLastName;
            textBoxes[2] = txtContact;
            textBoxes[3] = txtEmail;
            textBoxes[4] = txtRegNo;

            Student student = new Student(txtFirstName.Text, txtLastName.Text, txtContact.Text, txtEmail.Text,dtDOB.Text, cmbGender.Text, txtRegNo.Text);

            if (studentDL.insert(student))
            {
                MessageBox.Show("Student added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add student.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void Gender_Click(object sender, EventArgs e)
        {

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();    
        }
    }
}
