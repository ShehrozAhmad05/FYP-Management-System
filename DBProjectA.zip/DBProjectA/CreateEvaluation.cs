﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class CreateEvaluation : Form
    {
        EvaluationDL evaluationDL;

        public CreateEvaluation()
        {
            evaluationDL = new EvaluationDL();
            InitializeComponent();
        }

        private void CreateEvaluation_Load(object sender, EventArgs e)
        {
            

        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[3];
            textBoxes[0] = txtName;
            textBoxes[1] = txtTotalMarks;
            textBoxes[2] = txtTotalWeightage;

            if (evaluationDL.isAcceptableWeightage(txtTotalWeightage.Text))
            {
                Evaluation evaluation = new Evaluation(txtName.Text, txtTotalMarks.Text, txtTotalWeightage.Text);
                if (evaluationDL.insert(evaluation))
                {
                    MessageBox.Show("Data has been successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Cannot Insert Data.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Total Weightage of All Evaluations cannot be Greater than 100.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            EvaluationMenu evaluationMenu = new EvaluationMenu();
            evaluationMenu.Show();
            this.Close();
        }
    }
}
