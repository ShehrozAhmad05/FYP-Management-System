﻿namespace DBProjectA
{
    partial class AddAdvisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddAdvLogo = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.Gender = new System.Windows.Forms.Label();
            this.Designation = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AddBtn = new System.Windows.Forms.Button();
            this.cmbDesignation = new System.Windows.Forms.ComboBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.Salarylbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAddAdvLogo
            // 
            this.lblAddAdvLogo.AutoSize = true;
            this.lblAddAdvLogo.BackColor = System.Drawing.Color.White;
            this.lblAddAdvLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddAdvLogo.Location = new System.Drawing.Point(13, 9);
            this.lblAddAdvLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddAdvLogo.Name = "lblAddAdvLogo";
            this.lblAddAdvLogo.Size = new System.Drawing.Size(186, 40);
            this.lblAddAdvLogo.TabIndex = 74;
            this.lblAddAdvLogo.Text = "ADD ADVISOR";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(812, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 75;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // dtDOB
            // 
            this.dtDOB.CalendarFont = new System.Drawing.Font("Nirmala UI", 14.25F);
            this.dtDOB.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtDOB.Font = new System.Drawing.Font("Nirmala UI", 13F);
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDOB.Location = new System.Drawing.Point(472, 425);
            this.dtDOB.Margin = new System.Windows.Forms.Padding(4);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(257, 36);
            this.dtDOB.TabIndex = 90;
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblDOB.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblDOB.Location = new System.Drawing.Point(467, 396);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(139, 23);
            this.lblDOB.TabIndex = 89;
            this.lblDOB.Text = "Date Of Birth";
            // 
            // cmbGender
            // 
            this.cmbGender.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(470, 321);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(259, 33);
            this.cmbGender.TabIndex = 88;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Cursor = System.Windows.Forms.Cursors.Default;
            this.Gender.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Gender.Location = new System.Drawing.Point(468, 295);
            this.Gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(82, 23);
            this.Gender.TabIndex = 87;
            this.Gender.Text = "Gender";
            // 
            // Designation
            // 
            this.Designation.AutoSize = true;
            this.Designation.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Designation.Location = new System.Drawing.Point(115, 295);
            this.Designation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Designation.Name = "Designation";
            this.Designation.Size = new System.Drawing.Size(129, 23);
            this.Designation.TabIndex = 85;
            this.Designation.Text = "Designation";
            this.Designation.Click += new System.EventHandler(this.Designation_Click);
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtContact.Location = new System.Drawing.Point(118, 222);
            this.txtContact.Margin = new System.Windows.Forms.Padding(4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(257, 33);
            this.txtContact.TabIndex = 84;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtEmail.Location = new System.Drawing.Point(472, 222);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(257, 33);
            this.txtEmail.TabIndex = 83;
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Contact.Location = new System.Drawing.Point(114, 195);
            this.Contact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(86, 23);
            this.Contact.TabIndex = 82;
            this.Contact.Text = "Contact";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Cursor = System.Windows.Forms.Cursors.Default;
            this.Email.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Email.Location = new System.Drawing.Point(467, 192);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(63, 23);
            this.Email.TabIndex = 81;
            this.Email.Text = "Email";
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtLastName.Location = new System.Drawing.Point(472, 127);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(257, 33);
            this.txtLastName.TabIndex = 80;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtFirstName.Location = new System.Drawing.Point(119, 127);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(257, 33);
            this.txtFirstName.TabIndex = 79;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.label1.Location = new System.Drawing.Point(467, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 23);
            this.label1.TabIndex = 78;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 97);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 23);
            this.label2.TabIndex = 77;
            this.label2.Text = "First Name";
            // 
            // AddBtn
            // 
            this.AddBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.AddBtn.Location = new System.Drawing.Point(365, 506);
            this.AddBtn.Margin = new System.Windows.Forms.Padding(4);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(126, 49);
            this.AddBtn.TabIndex = 76;
            this.AddBtn.Text = "Add\r\n";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // cmbDesignation
            // 
            this.cmbDesignation.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.cmbDesignation.FormattingEnabled = true;
            this.cmbDesignation.Items.AddRange(new object[] {
            "Professor",
            "Associate Professor",
            "Assistant Professor",
            "Lecturer"});
            this.cmbDesignation.Location = new System.Drawing.Point(119, 321);
            this.cmbDesignation.Name = "cmbDesignation";
            this.cmbDesignation.Size = new System.Drawing.Size(259, 33);
            this.cmbDesignation.TabIndex = 91;
            // 
            // txtSalary
            // 
            this.txtSalary.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtSalary.Location = new System.Drawing.Point(119, 428);
            this.txtSalary.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(257, 33);
            this.txtSalary.TabIndex = 93;
            // 
            // Salarylbl
            // 
            this.Salarylbl.AutoSize = true;
            this.Salarylbl.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Salarylbl.Location = new System.Drawing.Point(115, 398);
            this.Salarylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Salarylbl.Name = "Salarylbl";
            this.Salarylbl.Size = new System.Drawing.Size(68, 23);
            this.Salarylbl.TabIndex = 92;
            this.Salarylbl.Text = "Salary";
            // 
            // AddAdvisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(866, 615);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.Salarylbl);
            this.Controls.Add(this.cmbDesignation);
            this.Controls.Add(this.dtDOB);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Designation);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblAddAdvLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddAdvisor";
            this.Text = "AddAdvisor";
            this.Load += new System.EventHandler(this.AddAdvisor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblAddAdvLogo;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.Label Designation;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.ComboBox cmbDesignation;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.Label Salarylbl;
    }
}