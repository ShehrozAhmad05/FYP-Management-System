﻿namespace DBProjectA
{
    partial class EditProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEditLogo = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.UpdateBtn = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.ProjectDesc = new System.Windows.Forms.Label();
            this.ProjectTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEditLogo
            // 
            this.lblEditLogo.AutoSize = true;
            this.lblEditLogo.BackColor = System.Drawing.Color.White;
            this.lblEditLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditLogo.Location = new System.Drawing.Point(13, 9);
            this.lblEditLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEditLogo.Name = "lblEditLogo";
            this.lblEditLogo.Size = new System.Drawing.Size(191, 40);
            this.lblEditLogo.TabIndex = 52;
            this.lblEditLogo.Text = "EDIT PROJECT";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(463, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 53;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.UpdateBtn.Location = new System.Drawing.Point(182, 396);
            this.UpdateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(146, 49);
            this.UpdateBtn.TabIndex = 92;
            this.UpdateBtn.Text = "Update";
            this.UpdateBtn.UseVisualStyleBackColor = true;
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.txtDescription.Location = new System.Drawing.Point(111, 237);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(293, 107);
            this.txtDescription.TabIndex = 91;
            // 
            // txtTitle
            // 
            this.txtTitle.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.txtTitle.Location = new System.Drawing.Point(111, 118);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(293, 35);
            this.txtTitle.TabIndex = 90;
            // 
            // ProjectDesc
            // 
            this.ProjectDesc.AutoSize = true;
            this.ProjectDesc.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.ProjectDesc.Location = new System.Drawing.Point(106, 207);
            this.ProjectDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ProjectDesc.Name = "ProjectDesc";
            this.ProjectDesc.Size = new System.Drawing.Size(236, 27);
            this.ProjectDesc.TabIndex = 89;
            this.ProjectDesc.Text = "Project Description";
            // 
            // ProjectTitle
            // 
            this.ProjectTitle.AutoSize = true;
            this.ProjectTitle.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.ProjectTitle.Location = new System.Drawing.Point(106, 88);
            this.ProjectTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ProjectTitle.Name = "ProjectTitle";
            this.ProjectTitle.Size = new System.Drawing.Size(151, 27);
            this.ProjectTitle.TabIndex = 88;
            this.ProjectTitle.Text = "Project Title";
            // 
            // EditProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(517, 494);
            this.Controls.Add(this.UpdateBtn);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.ProjectDesc);
            this.Controls.Add(this.ProjectTitle);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblEditLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditProject";
            this.Text = "EditProject";
            this.Load += new System.EventHandler(this.EditProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblEditLogo;
        private System.Windows.Forms.Button UpdateBtn;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label ProjectDesc;
        private System.Windows.Forms.Label ProjectTitle;
    }
}