﻿using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ViewGroups : Form
    {
        GroupDL groupDL;
        //Panel pnlChildForm;
        public ViewGroups()
        {
            //this.pnlChildForm = PnlchildForm;
            groupDL = new GroupDL();
            InitializeComponent();
        }

        private void ViewGroups_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!groupDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                return;
            }
            
            DGV.DataSource = groupDL.getList();
            changeDGVorder();
        }

        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["Created_On"].DisplayIndex = 1;
        }

        /*private void openChildForm(Form childForm)
        {
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            pnlChildForm.Controls.Add(childForm);
            pnlChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }*/

        private void mngGrpbtn_Click(object sender, EventArgs e)
        {
            int rowIdx = DGV.SelectedRows[0].Index;
            string groupId = DGV.Rows[rowIdx].Cells["Id"].Value.ToString();
            ManageGroup manageGroup=new ManageGroup(groupId);
            manageGroup.Show();
            //openChildForm(new ManageGroup(groupId));
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            GroupMenu groupMenu = new GroupMenu();
            this.Close();
            groupMenu.Show();
        }
    }
}
