﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ReportsMenu : Form
    {
        public ReportsMenu()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateGroupWiseEvalutionsResult(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AllStudentsBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateListOfAllStudents(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private SaveFileDialog resultOfSaveDialog()
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "PDF (*.pdf)|*.pdf";
            save.FileName = "Report.pdf";

            if (save.ShowDialog() != DialogResult.OK)
                return null;
            return save;
        }

        private void AllAdvisorsBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateListOfAllAdvisors(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NGrpProjBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateNonGroupProjects(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NGrpStdBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateNonGroupStudents(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NPrjAdvBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateNonProjectAdvisors(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        private void EvaluationStatusbtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = resultOfSaveDialog();
            if (save != null)
            {
                Report rep = new Report();
                FileStream fs = rep.getStream(save);
                if (fs == null)
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!rep.generateEvalutionsStatus(fs))
                {
                    MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Report Generated Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            else
            {
                MessageBox.Show("Report Cannot Be Generated.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();
        }
    }
}
