﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ViewProject : Form
    {
        ProjectDL projectDL;
        EditProject formUpdate;

        public ViewProject()
        {
            projectDL = new ProjectDL();
            InitializeComponent();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            ProjectMenu projectMenu = new ProjectMenu();
            this.Close();
            projectMenu.Show();

        }

        private void ViewProject_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!projectDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            DGV.DataSource = projectDL.getList();
            changeDGVorder();
        }

        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["Title"].DisplayIndex = 1;
            DGV.Columns["Description"].DisplayIndex = 2;
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            string id = DGV.Rows[rowIdx].Cells["Id"].Value.ToString();
            string title = DGV.Rows[rowIdx].Cells["Title"].Value.ToString();
            string description = DGV.Rows[rowIdx].Cells["Description"].Value.ToString();
            formUpdate = new EditProject(new Project(id, description, title));
            formUpdate.onSuccessUpdate += new EventHandler(onSuccessUpdate);
            formUpdate.ShowDialog();
        }

        private void onSuccessUpdate(object sender, EventArgs e)
        {
            updateDGV();
        }

        private void updateDGV()
        {
            projectDL.fetchRecords();
            DGV.DataSource = projectDL.getList();
            changeDGVorder();
        }
    }
}
