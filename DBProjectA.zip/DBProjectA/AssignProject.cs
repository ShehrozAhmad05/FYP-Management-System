﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class AssignProject : Form
    {
        GroupDL groupDL;
        ProjectDL projectDL;
        AdvisorDL advisorDL;
        GroupProjectDL groupProjectDL;
        ProjectAdvisorDL projectAdvisorDL;
        string groupId;
        string projectId;
        string mainAdvisorId = null;
        string coAdvisorId = null;
        string industryAdvisorId = null;

        public AssignProject()
        {
            groupDL = new GroupDL();
            projectDL = new ProjectDL();
            advisorDL = new AdvisorDL();
            groupProjectDL = new GroupProjectDL();
            projectAdvisorDL = new ProjectAdvisorDL();
            InitializeComponent();
        }

        private void AssignProject_Load(object sender, EventArgs e)
        {
            DGV_group.MultiSelect = false;
            DGV_project.MultiSelect = false;
            selectprjbtn.Visible = false;
            cmbMainAdvisor.Visible = false;
            cmbCoAdvisor.Visible = false;
            cmbIndustryAdvisor.Visible = false;
            btnAssignprj.Visible = false;
            selectadvisorbtn.Visible = false;
            lblCoAdvisor.Visible = false;
            lblMainAdvisor.Visible = false;
            lblIndAdvisor.Visible = false;
            if (!groupDL.fetchNonGroupStudents())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            DGV_group.DataSource = groupDL.getList();

        }

        private void selectGrpbtn_Click(object sender, EventArgs e)
        {
            if (DGV_group.RowCount == 0)
                return;
            int rowIdx = DGV_group.SelectedRows[0].Index;
            if (!projectDL.fetchNonGroupProjects())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                DGV_project.DataSource = projectDL.getList();
                selectprjbtn.Visible = true;
                DGV_group.Enabled = false;
                groupId = DGV_group.Rows[rowIdx].Cells["Id"].Value.ToString();
                selectGrpbtn.Enabled = false;
                selectGrpbtn.BackColor = Color.White;
                selectGrpbtn.ForeColor = Color.White;
            }
        }

        private void selectprjbtn_Click(object sender, EventArgs e)
        {
            if (DGV_project.RowCount == 0)
                return;
            int rowIdx = DGV_project.SelectedRows[0].Index;
            projectId = DGV_project.Rows[rowIdx].Cells["Id"].Value.ToString();
            DGV_project.Enabled = false;
            cmbCoAdvisor.Visible = true;
            cmbMainAdvisor.Visible = true;
            cmbIndustryAdvisor.Visible = true;
            cmbCoAdvisor.Enabled = false;
            cmbIndustryAdvisor.Enabled = false;
            lblCoAdvisor.Visible = true;
            lblMainAdvisor.Visible = true;
            lblIndAdvisor.Visible = true;
            if (advisorDL.fetchAdvisorsForProject())
            {
                cmbMainAdvisor.DataSource = advisorDL.getAdvisorListForProject();
                selectadvisorbtn.Text = "Select Main Advisor";
                selectadvisorbtn.Visible = true;
                selectprjbtn.Enabled = false;
                selectprjbtn.BackColor = Color.White;
                selectprjbtn.ForeColor = Color.White;

            }
            else
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (mainAdvisorId == null)
            {
                string[] txt = cmbMainAdvisor.Text.Split('-');
                mainAdvisorId = txt[0];
                List<string> lst = new List<string>();
                lst = (List<string>)cmbMainAdvisor.DataSource;
                lst.RemoveAt(cmbMainAdvisor.SelectedIndex);
                cmbCoAdvisor.DataSource = lst;
                cmbCoAdvisor.Enabled = true;
                cmbMainAdvisor.Enabled = false;
                selectadvisorbtn.Text = "Select Co Advisor";
            }
            else if (coAdvisorId == null)
            {
                string[] txt = cmbCoAdvisor.Text.Split('-');
                coAdvisorId = txt[0];
                List<string> lst = new List<string>();
                lst = (List<string>)cmbCoAdvisor.DataSource;
                lst.RemoveAt(cmbCoAdvisor.SelectedIndex);
                cmbIndustryAdvisor.DataSource = lst;
                cmbIndustryAdvisor.Enabled = true;
                cmbCoAdvisor.Enabled = false;
                selectadvisorbtn.Text = "Select Industry Advisor";
            }
            else if (industryAdvisorId == null)
            {
                string[] txt = cmbIndustryAdvisor.Text.Split('-');
                industryAdvisorId = txt[0];
                cmbIndustryAdvisor.Enabled = false;
                selectadvisorbtn.Enabled = false;
                btnAssignprj.Visible = true;
            }
        }

        private void btnAssignprj_Click(object sender, EventArgs e)
        {
            if (mainAdvisorId.Length == 0 || coAdvisorId.Length == 0 || industryAdvisorId.Length == 0)
            {
                MessageBox.Show("Please Select All Advisors.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DateTime createdOn = new DateTime();
                createdOn = DateTime.Now;
                GroupProject gp = new GroupProject(projectId, groupId, createdOn.ToString());
                if (!groupProjectDL.insert(gp))
                {
                    MessageBox.Show("Cannot Insert Data.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    bool success = false;
                    ProjectAdvisor pa = new ProjectAdvisor(mainAdvisorId, projectId, "Main Advisor", createdOn.ToString());
                    if (projectAdvisorDL.insert(pa))
                    {
                        pa = new ProjectAdvisor(coAdvisorId, projectId, "Co-Advisor", createdOn.ToString());

                        if (projectAdvisorDL.insert(pa))
                        {
                            pa = new ProjectAdvisor(industryAdvisorId, projectId, "Industry Advisor", createdOn.ToString());
                            if (projectAdvisorDL.insert(pa))
                            {
                                success = true;
                            }
                        }
                    }
                    if (success)
                    {
                        MessageBox.Show("Data has been successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please Select All Advisors.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            GroupMenu groupMenu = new GroupMenu();
            this.Close();
            groupMenu.Show();

        }
    }
}
