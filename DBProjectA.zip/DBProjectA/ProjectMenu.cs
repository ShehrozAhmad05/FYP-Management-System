﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ProjectMenu : Form
    {
        public ProjectMenu()
        {
            InitializeComponent();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();
        }

        private void AddPrjctBtn_Click(object sender, EventArgs e)
        {
            AddProject addProject = new AddProject();
            this.Close();
            addProject.Show();
        }

        private void ViewprjctBtn_Click(object sender, EventArgs e)
        {
            ViewProject viewProject = new ViewProject();
            this.Close();
            viewProject.Show();

        }
    }
}
