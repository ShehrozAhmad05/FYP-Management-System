﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EditAdvisor : Form
    {

        string Id, designation, gender;
        Advisor adv;
        AdvisorDL advisorDL;

        public event EventHandler onSuccessUpdate;

        private void EditBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[5];
            textBoxes[0] = txtFirstName;
            textBoxes[1] = txtLastName;
            textBoxes[2] = txtContact;
            textBoxes[3] = txtEmail;
            textBoxes[4] = txtSalary;

            adv.FirstName = txtFirstName.Text;
            adv.LastName = txtLastName.Text;
            adv.Contact = txtContact.Text;
            adv.Email = txtEmail.Text;
            adv.DateOfBirth = adv.parseDate(dtDOB.Text);
            adv.Gender = cmbGender.Text;
            adv.Salary = txtSalary.Text;
            adv.Designation = cmbDesignation.Text;
            if (advisorDL.update(adv))
            {
                MessageBox.Show("Record Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                onSuccessUpdate?.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill the correct information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public EditAdvisor(Advisor adv)
        {
            InitializeComponent();
            this.adv = adv;
            advisorDL = new AdvisorDL();
            this.txtFirstName.Text = adv.FirstName;
            txtLastName.Text = adv.LastName;
            txtContact.Text = adv.Contact;
            txtEmail.Text = adv.Email;
            this.Id = adv.Id;
            txtSalary.Text = adv.Salary;
            this.designation = adv.Designation;
            cmbGender.Text = adv.Gender;
            dtDOB.Text = adv.DateOfBirth;
        }

        private void EditAdvisor_Load(object sender, EventArgs e)
        {
            DataTable dt = advisorDL.getDesginationValues();
            if (dt == null)
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                List<string> designations = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    designations.Add(dt.Rows[i][0].ToString());
                }
                cmbDesignation.DataSource = designations;
                cmbDesignation.Text = designation;
            }
        }
    }
}
