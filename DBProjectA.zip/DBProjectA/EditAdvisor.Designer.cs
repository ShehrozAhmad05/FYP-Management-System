﻿namespace DBProjectA
{
    partial class EditAdvisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.lblEditLogo = new System.Windows.Forms.Label();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.Gender = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.lblDOB = new System.Windows.Forms.Label();
            this.EditBtn = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.Salary = new System.Windows.Forms.Label();
            this.cmbDesignation = new System.Windows.Forms.ComboBox();
            this.Designation = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbGender
            // 
            this.cmbGender.Font = new System.Drawing.Font("Lucida Sans", 9.5F);
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Location = new System.Drawing.Point(114, 520);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(259, 26);
            this.cmbGender.TabIndex = 69;
            // 
            // lblEditLogo
            // 
            this.lblEditLogo.AutoSize = true;
            this.lblEditLogo.BackColor = System.Drawing.Color.White;
            this.lblEditLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditLogo.Location = new System.Drawing.Point(8, 9);
            this.lblEditLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEditLogo.Name = "lblEditLogo";
            this.lblEditLogo.Size = new System.Drawing.Size(192, 40);
            this.lblEditLogo.TabIndex = 67;
            this.lblEditLogo.Text = "EDIT ADVISOR";
            // 
            // dtDOB
            // 
            this.dtDOB.CalendarFont = new System.Drawing.Font("Nirmala UI", 14.25F);
            this.dtDOB.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtDOB.Font = new System.Drawing.Font("Nirmala UI", 13F);
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDOB.Location = new System.Drawing.Point(116, 659);
            this.dtDOB.Margin = new System.Windows.Forms.Padding(4);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(257, 36);
            this.dtDOB.TabIndex = 66;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Cursor = System.Windows.Forms.Cursors.Default;
            this.Gender.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Gender.Location = new System.Drawing.Point(111, 494);
            this.Gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(82, 23);
            this.Gender.TabIndex = 65;
            this.Gender.Text = "Gender";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtContact.Location = new System.Drawing.Point(116, 277);
            this.txtContact.Margin = new System.Windows.Forms.Padding(4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(257, 33);
            this.txtContact.TabIndex = 64;
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblDOB.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblDOB.Location = new System.Drawing.Point(111, 630);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(139, 23);
            this.lblDOB.TabIndex = 63;
            this.lblDOB.Text = "Date Of Birth";
            // 
            // EditBtn
            // 
            this.EditBtn.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.EditBtn.Location = new System.Drawing.Point(185, 724);
            this.EditBtn.Margin = new System.Windows.Forms.Padding(4);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(115, 45);
            this.EditBtn.TabIndex = 62;
            this.EditBtn.Text = "Edit";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtEmail.Location = new System.Drawing.Point(116, 362);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(257, 33);
            this.txtEmail.TabIndex = 61;
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtLastName.Location = new System.Drawing.Point(116, 193);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(257, 33);
            this.txtLastName.TabIndex = 60;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtFirstName.Location = new System.Drawing.Point(116, 105);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(257, 33);
            this.txtFirstName.TabIndex = 59;
            // 
            // txtSalary
            // 
            this.txtSalary.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtSalary.Location = new System.Drawing.Point(116, 443);
            this.txtSalary.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(257, 33);
            this.txtSalary.TabIndex = 58;
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Contact.Location = new System.Drawing.Point(112, 250);
            this.Contact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(86, 23);
            this.Contact.TabIndex = 57;
            this.Contact.Text = "Contact";
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.LastName.Location = new System.Drawing.Point(111, 163);
            this.LastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(112, 23);
            this.LastName.TabIndex = 56;
            this.LastName.Text = "Last Name";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Cursor = System.Windows.Forms.Cursors.Default;
            this.Email.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Email.Location = new System.Drawing.Point(111, 332);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(63, 23);
            this.Email.TabIndex = 55;
            this.Email.Text = "Email";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstName.Location = new System.Drawing.Point(111, 75);
            this.FirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(115, 23);
            this.FirstName.TabIndex = 54;
            this.FirstName.Text = "First Name";
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Salary.Location = new System.Drawing.Point(111, 413);
            this.Salary.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(68, 23);
            this.Salary.TabIndex = 53;
            this.Salary.Text = "Salary";
            // 
            // cmbDesignation
            // 
            this.cmbDesignation.Font = new System.Drawing.Font("Lucida Sans", 9.5F);
            this.cmbDesignation.FormattingEnabled = true;
            this.cmbDesignation.Location = new System.Drawing.Point(116, 591);
            this.cmbDesignation.Name = "cmbDesignation";
            this.cmbDesignation.Size = new System.Drawing.Size(259, 26);
            this.cmbDesignation.TabIndex = 71;
            // 
            // Designation
            // 
            this.Designation.AutoSize = true;
            this.Designation.Cursor = System.Windows.Forms.Cursors.Default;
            this.Designation.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.Designation.Location = new System.Drawing.Point(113, 565);
            this.Designation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Designation.Name = "Designation";
            this.Designation.Size = new System.Drawing.Size(129, 23);
            this.Designation.TabIndex = 70;
            this.Designation.Text = "Designation";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(445, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 68;
            this.pbCloseButton2.TabStop = false;
            // 
            // EditAdvisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(500, 796);
            this.Controls.Add(this.cmbDesignation);
            this.Controls.Add(this.Designation);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblEditLogo);
            this.Controls.Add(this.dtDOB);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.Salary);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditAdvisor";
            this.Text = "EditAdvisor";
            this.Load += new System.EventHandler(this.EditAdvisor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblEditLogo;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.Label LastName;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.ComboBox cmbDesignation;
        private System.Windows.Forms.Label Designation;
    }
}