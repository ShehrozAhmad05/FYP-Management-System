﻿namespace DBProjectA
{
    partial class GroupMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCreatelogo = new System.Windows.Forms.Label();
            this.ViewGrpBtn = new System.Windows.Forms.Button();
            this.CreateGrpBtn = new System.Windows.Forms.Button();
            this.BtnAssignProject = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCreatelogo
            // 
            this.lblCreatelogo.AutoSize = true;
            this.lblCreatelogo.BackColor = System.Drawing.Color.White;
            this.lblCreatelogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreatelogo.Location = new System.Drawing.Point(13, 9);
            this.lblCreatelogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCreatelogo.Name = "lblCreatelogo";
            this.lblCreatelogo.Size = new System.Drawing.Size(177, 40);
            this.lblCreatelogo.TabIndex = 55;
            this.lblCreatelogo.Text = "GROUP MENU";
            // 
            // ViewGrpBtn
            // 
            this.ViewGrpBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.ViewGrpBtn.Location = new System.Drawing.Point(486, 155);
            this.ViewGrpBtn.Name = "ViewGrpBtn";
            this.ViewGrpBtn.Size = new System.Drawing.Size(228, 89);
            this.ViewGrpBtn.TabIndex = 63;
            this.ViewGrpBtn.Text = "View Groups";
            this.ViewGrpBtn.UseVisualStyleBackColor = true;
            this.ViewGrpBtn.Click += new System.EventHandler(this.ViewGrpBtn_Click);
            // 
            // CreateGrpBtn
            // 
            this.CreateGrpBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.CreateGrpBtn.Location = new System.Drawing.Point(151, 155);
            this.CreateGrpBtn.Name = "CreateGrpBtn";
            this.CreateGrpBtn.Size = new System.Drawing.Size(228, 89);
            this.CreateGrpBtn.TabIndex = 62;
            this.CreateGrpBtn.Text = "Create Group";
            this.CreateGrpBtn.UseVisualStyleBackColor = true;
            this.CreateGrpBtn.Click += new System.EventHandler(this.CreateGrpBtn_Click);
            // 
            // BtnAssignProject
            // 
            this.BtnAssignProject.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.BtnAssignProject.Location = new System.Drawing.Point(321, 317);
            this.BtnAssignProject.Name = "BtnAssignProject";
            this.BtnAssignProject.Size = new System.Drawing.Size(228, 89);
            this.BtnAssignProject.TabIndex = 64;
            this.BtnAssignProject.Text = "Assign Project";
            this.BtnAssignProject.UseVisualStyleBackColor = true;
            this.BtnAssignProject.Click += new System.EventHandler(this.BtnAssignProject_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(820, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 56;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // GroupMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(874, 530);
            this.Controls.Add(this.BtnAssignProject);
            this.Controls.Add(this.ViewGrpBtn);
            this.Controls.Add(this.CreateGrpBtn);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblCreatelogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GroupMenu";
            this.Text = "GroupMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCreatelogo;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Button ViewGrpBtn;
        private System.Windows.Forms.Button CreateGrpBtn;
        private System.Windows.Forms.Button BtnAssignProject;
    }
}