﻿using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ManageGroup : Form
    {
        string groupId;
        GroupStudentDL groupStudentDL;
        List<int> inActiveRows;
        public ManageGroup(string groupId)
        {
            this.groupId = groupId;
            groupStudentDL = new GroupStudentDL();
            inActiveRows = new List<int>();
            InitializeComponent();
        }

        private void ManageGroup_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            DGV.CellContentClick += new DataGridViewCellEventHandler(DGV_CellClick);
            DataTable dt = groupStudentDL.fetchRecords(groupId);
            if (dt == null)
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            groupStudentDL.fetchRecords(groupId);
            bindData(dt);
        }

        private void bindData(DataTable dt)
        {
            dt.Columns.Add("chkBoxActive", typeof(bool));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["chkBoxActive"] = true;

            }
            DGV.DataSource = dt;
            foreach (DataGridViewColumn column in DGV.Columns)
            {
                column.ReadOnly = true;
            }
            DGV.Columns["chkBoxActive"].ReadOnly = false;

        }

        private void DGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Check to ensure that the row CheckBox is clicked.
            if (e.RowIndex >= 0/* && e.ColumnIndex == 0*/)
            {
                //Reference the GridView Row.
                DataGridViewRow row = DGV.Rows[e.RowIndex];

                //Set the CheckBox selection.
                row.Cells["chkBoxActive"].Value = !Convert.ToBoolean(row.Cells["chkBoxActive"].EditedFormattedValue);

                //If CheckBox is checked, display Message Box.
                if (Convert.ToBoolean(row.Cells["chkBoxActive"].Value))
                {
                    inActiveRows.Remove(e.RowIndex);
                }
                if (!Convert.ToBoolean(row.Cells["chkBoxActive"].Value))
                {
                    inActiveRows.Add(e.RowIndex);
                }
            }

        }

        private void AddStdbtn_Click(object sender, EventArgs e)
        {
            AddStudentToGroup form = new AddStudentToGroup(groupId);
            this.Close();
            form.Show();
            SqlQueries.fillManageGroupStudentDGV(DGV, groupId);
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (inActiveRows.Count == 0)
                return;
            for (int i = 0; i < DGV.RowCount; i++)
            {
                if (DGV.Rows[i].Cells["chkBoxActive"].Value.ToString() == "False")
                {
                    if (!SqlQueries.updateGroupStudentStatus(false, DGV.Rows[i].Cells[0].Value.ToString()))
                        goto Error;
                }
            }

            MessageBox.Show("Data Has Been Successfully Updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
            goto End;
        Error:;

            MessageBox.Show("Failed to Update.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            this.Close();
        End:;
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
