﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class AdvisorMenu : Form
    {
        public AdvisorMenu()
        {
            InitializeComponent();
        }

        private void AddAdvBtn_Click(object sender, EventArgs e)
        {
            AddAdvisor addAdvisor = new AddAdvisor();
            this.Close();
            addAdvisor.Show(); 
        }

        private void ViewAdvBtn_Click(object sender, EventArgs e)
        {
            ViewAdvisor viewAdvisor = new ViewAdvisor();
            this.Close();
            viewAdvisor.Show();

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();

        }

        private void AdvisorMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
