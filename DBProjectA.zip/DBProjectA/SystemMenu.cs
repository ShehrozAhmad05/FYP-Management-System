﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class SystemMenu : Form
    {
        public SystemMenu()
        {
            InitializeComponent();
        }

        private void StudentBtn_Click(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm();
            this.Hide();
            studentForm.Show();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AdvisorBtn_Click(object sender, EventArgs e)
        {
            AdvisorMenu advisor = new AdvisorMenu();
            this.Hide();
            advisor.Show();
        }

        private void ProjectBtn_Click(object sender, EventArgs e)
        {
            ProjectMenu projectMenu = new ProjectMenu();
            this.Hide();
            projectMenu.Show();
        }

        private void GroupsBtn_Click(object sender, EventArgs e)
        {
            GroupMenu groupMenu = new GroupMenu();
            this.Hide();
            groupMenu.Show();
        }

        private void EvaluationBtn_Click(object sender, EventArgs e)
        {
            EvaluationMenu evaluationMenu = new EvaluationMenu();
            this.Hide();
            evaluationMenu.Show();
        }

        private void btnGrpEvaluations_Click(object sender, EventArgs e)
        {
            GroupEvaluationsMenu groupEvaluationsMenu = new GroupEvaluationsMenu();
            this.Hide();
            groupEvaluationsMenu.Show();
        }

        private void ReportBtn_Click(object sender, EventArgs e)
        {
            ReportsMenu reportsMenu = new ReportsMenu();
            this.Hide();
            reportsMenu.Show();
        }

        private void SystemMenu_Load(object sender, EventArgs e)
        {

        }


    }
}
