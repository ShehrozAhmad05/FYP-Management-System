﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ManageEvaluation : Form
    {
        EvaluationDL evaluationDL;
        public ManageEvaluation()
        {
            evaluationDL = new EvaluationDL();
            InitializeComponent();
        }

        private void ManageEvaluation_Load(object sender, EventArgs e)
        {
            this.UpdateBtn.Hide();
            DGV.MultiSelect = false;
            if (!evaluationDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            DGV.DataSource = evaluationDL.getList();
            changeDGVorder();
        }

        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["Name"].DisplayIndex = 1;
            DGV.Columns["TotalMarks"].DisplayIndex = 2;
            DGV.Columns["TotalWeightage"].DisplayIndex = 3;

            DGV.Columns["TotalWeightage"].HeaderText = "Total Weightage";
            DGV.Columns["TotalMarks"].HeaderText = "Total Marks";
        }

        private void Selectbtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            List<Evaluation> lst = (List<Evaluation>)DGV.DataSource;
            Evaluation evaluation = lst[rowIdx];
            txtName.Text = evaluation.Name;
            txtTotalMarks.Text = evaluation.Totalmarks;
            txtTotalWeightage.Text = evaluation.TotalWeightage;
            UpdateBtn.Visible = true;
            DGV.Enabled = false;
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[3];
            textBoxes[0] = txtName;
            textBoxes[1] = txtTotalMarks;
            textBoxes[2] = txtTotalWeightage;

            string id = ((List<Evaluation>)DGV.DataSource)[DGV.SelectedRows[0].Index].Id;
            Evaluation evaluation = new Evaluation(id, txtName.Text, txtTotalMarks.Text, txtTotalWeightage.Text);
            if (evaluationDL.isAcceptableWeightageUpdate(id, txtTotalWeightage.Text))
            {
                if (evaluationDL.update(evaluation))
                {
                    MessageBox.Show("Data Has Been Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed To Update", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Total Weightage of All Evaluations cannot be Greater than 100.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            EvaluationMenu evaluationMenu = new EvaluationMenu();
            evaluationMenu.Show();
            this.Close();
        }
    }
}
