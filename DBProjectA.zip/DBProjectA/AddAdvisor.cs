﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class AddAdvisor : Form
    {
        AdvisorDL AdvisorDL;

        public AddAdvisor()
        {
            AdvisorDL = new AdvisorDL();
            InitializeComponent();
        }

        private void txtRegNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void Designation_Click(object sender, EventArgs e)
        {

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            AdvisorMenu menu = new AdvisorMenu();
            this.Close();
            menu.Show();
        }

        private void AddAdvisor_Load(object sender, EventArgs e)
        {
            if (!SqlQueries.fillDesignationsCBX(cmbDesignation))
            {
                MessageBox.Show("SomeThing Went Wrong");
                this.AddBtn.Enabled = false;
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[5];
            textBoxes[0] = txtFirstName;
            textBoxes[1] = txtLastName;
            textBoxes[2] = txtContact;
            textBoxes[3] = txtEmail;
            textBoxes[4] = txtSalary;

            Advisor advisor = new Advisor(txtFirstName.Text, txtLastName.Text, txtContact.Text, txtEmail.Text, dtDOB.Text, cmbGender.Text, cmbDesignation.Text, txtSalary.Text);

            if (AdvisorDL.insert(advisor))
            {
                MessageBox.Show("Advisor added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add advisor.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
