﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class GroupEvaluationsMenu : Form
    {
        public GroupEvaluationsMenu()
        {
            InitializeComponent();
        }

        private void BtnMarkEvaluations_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            this.Close();
            markEvaluation.Show();
        }

        private void ViewAdvBtn_Click(object sender, EventArgs e)
        {
            EditMarkEvaluation editMarkEvaluation = new EditMarkEvaluation();
            editMarkEvaluation.Show();
            this.Close();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();
        }
    }
}
