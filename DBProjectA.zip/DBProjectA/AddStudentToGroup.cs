﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class AddStudentToGroup : Form
    {
        StudentDL studentDL;
        GroupStudentDL groupStudentDl;
        List<int> selectedRows;
        string groupId;
        public AddStudentToGroup(string groupId)
        {
            InitializeComponent();
            selectedRows = new List<int>();
            studentDL = new StudentDL();
            groupStudentDl = new GroupStudentDL();
            this.groupId = groupId;
        }

        private void bindData()
        {

            if (!studentDL.fetchNonGroupStudents())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            List<Student> lstStd = studentDL.getList();
            DGV.DataSource = lstStd;
            changeDGVorder();
        }
        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["RegistrationNumber"].DisplayIndex = 1;
            DGV.Columns["FirstName"].DisplayIndex = 2;
            DGV.Columns["LastName"].DisplayIndex = 3;
            DGV.Columns["Contact"].DisplayIndex = 4;
            DGV.Columns["Email"].DisplayIndex = 5;


            DGV.Columns["DateOfBirth"].DisplayIndex = 6;
            DGV.Columns["Gender"].DisplayIndex = 7;
            DGV.Columns["RegistrationNumber"].HeaderText = "Registration Number";
            DGV.Columns["FirstName"].HeaderText = "First Name";
            DGV.Columns["LastName"].HeaderText = "Last Name";

            DGV.Columns["DateOfBirth"].Visible = false;
            DGV.Columns["Gender"].Visible = false;
            DataGridViewCheckBoxColumn clm = new DataGridViewCheckBoxColumn();
            clm.ValueType = typeof(bool);
            clm.Name = "chkBoxSelected";
            clm.HeaderText = "Selected";
            DGV.Columns.Add(clm);
            DGV.ReadOnly = false;
            foreach (DataGridViewColumn column in DGV.Columns)
            {
                column.ReadOnly = true;
            }
            DGV.Columns["chkBoxSelected"].ReadOnly = false;
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Check to ensure that the row CheckBox is clicked.
            if (e.RowIndex >= 0/* && e.ColumnIndex == 0*/)
            {
                //Reference the GridView Row.
                DataGridViewRow row = DGV.Rows[e.RowIndex];

                //Set the CheckBox selection.
                row.Cells["chkBoxSelected"].Value = Convert.ToBoolean(row.Cells["chkBoxSelected"].EditedFormattedValue);

                //If CheckBox is checked, display Message Box.
                if (Convert.ToBoolean(row.Cells["chkBoxSelected"].Value))
                {
                    selectedRows.Add(e.RowIndex);
                }
                if (!Convert.ToBoolean(row.Cells["chkBoxSelected"].Value))
                {
                    selectedRows.Remove(e.RowIndex);
                }
            }
        }

        private void AddStudentToGroup_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            DGV.CellContentClick += new DataGridViewCellEventHandler(DGV_CellClick);
            bindData();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (selectedRows.Count == 0)
            {

                MessageBox.Show("Please select students.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DateTime createdOn = new DateTime();
            createdOn = DateTime.Now;


            bool success = true;
            foreach (var i in selectedRows)
            {
                string studentId = DGV.Rows[i].Cells["Id"].Value.ToString();
                GroupStudent groupStudent = new GroupStudent(studentId, "Active", createdOn.ToString(), groupId);
                if (!groupStudentDl.insert(groupStudent))
                {
                    MessageBox.Show("Cannot Insert Data.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    success = false;
                    break;
                }
            }
            if (success)
            {
                MessageBox.Show("Data has been successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                bindData();
                selectedRows.Clear();
            }
            this.Close();
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
