﻿using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EditSelectEvaluation : Form
    {
        EditObtainedMarksEvaluation formMarkEvaluation;
        GroupEvaluationDL groupEvaluationDL;
        string groupId;
        public EditSelectEvaluation(string groupId)
        {
            groupEvaluationDL = new GroupEvaluationDL();
            this.groupId = groupId;
            InitializeComponent();
        }

        private void EditSelectEvaluation_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            bindData();
        }

        void bindData()
        {
            DGV.DataSource = null;
            DataTable dt = groupEvaluationDL.fetchGroupEvaluationsDataTable(groupId);
            if (dt == null)
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }

            dt.Columns.Add("ObtainedMarks", typeof(string));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["ObtainedMarks"] = groupEvaluationDL.getObtainedMarks(groupId, dt.Rows[i]["Id"].ToString());

            }
            DGV.DataSource = dt;
            foreach (DataGridViewColumn column in DGV.Columns)
            {
                column.ReadOnly = true;
            }
        }

        private void SelectBtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;

            formMarkEvaluation = new EditObtainedMarksEvaluation(groupId, DGV.Rows[rowIdx].Cells["Id"].Value.ToString(),
                                                                         DGV.Rows[rowIdx].Cells["TotalMarks"].Value.ToString(),
                                                                         DGV.Rows[rowIdx].Cells["TotalWeightage"].Value.ToString(),
                                                                         groupEvaluationDL.getObtainedMarks(groupId,
                                                                         DGV.Rows[rowIdx].Cells["Id"].Value.ToString()));
            formMarkEvaluation.onSuccess += new EventHandler(onSuccessEvaluation);
            formMarkEvaluation.ShowDialog();
        }

        private void onSuccessEvaluation(object sender, EventArgs e)
        {
            bindData();
        }
    }
}
