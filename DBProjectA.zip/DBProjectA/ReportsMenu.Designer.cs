﻿namespace DBProjectA
{
    partial class ReportsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AllStudentsBtn = new System.Windows.Forms.Button();
            this.lblViewLogo = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.AllAdvisorsBtn = new System.Windows.Forms.Button();
            this.NGrpStdBtn = new System.Windows.Forms.Button();
            this.NGrpProjBtn = new System.Windows.Forms.Button();
            this.EvaluationStatusbtn = new System.Windows.Forms.Button();
            this.NPrjAdvBtn = new System.Windows.Forms.Button();
            this.GrpEvaluations = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // AllStudentsBtn
            // 
            this.AllStudentsBtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.AllStudentsBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.AllStudentsBtn.Location = new System.Drawing.Point(72, 94);
            this.AllStudentsBtn.Name = "AllStudentsBtn";
            this.AllStudentsBtn.Size = new System.Drawing.Size(234, 71);
            this.AllStudentsBtn.TabIndex = 64;
            this.AllStudentsBtn.Text = "All Students";
            this.AllStudentsBtn.UseVisualStyleBackColor = false;
            this.AllStudentsBtn.Click += new System.EventHandler(this.AllStudentsBtn_Click);
            // 
            // lblViewLogo
            // 
            this.lblViewLogo.AutoSize = true;
            this.lblViewLogo.BackColor = System.Drawing.Color.White;
            this.lblViewLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewLogo.Location = new System.Drawing.Point(13, 9);
            this.lblViewLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblViewLogo.Name = "lblViewLogo";
            this.lblViewLogo.Size = new System.Drawing.Size(266, 40);
            this.lblViewLogo.TabIndex = 62;
            this.lblViewLogo.Text = "GENERATE REPORTS";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(658, 5);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 63;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // AllAdvisorsBtn
            // 
            this.AllAdvisorsBtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.AllAdvisorsBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.AllAdvisorsBtn.Location = new System.Drawing.Point(391, 94);
            this.AllAdvisorsBtn.Name = "AllAdvisorsBtn";
            this.AllAdvisorsBtn.Size = new System.Drawing.Size(234, 71);
            this.AllAdvisorsBtn.TabIndex = 65;
            this.AllAdvisorsBtn.Text = "All Advisors";
            this.AllAdvisorsBtn.UseVisualStyleBackColor = false;
            this.AllAdvisorsBtn.Click += new System.EventHandler(this.AllAdvisorsBtn_Click);
            // 
            // NGrpStdBtn
            // 
            this.NGrpStdBtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.NGrpStdBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.NGrpStdBtn.Location = new System.Drawing.Point(391, 199);
            this.NGrpStdBtn.Name = "NGrpStdBtn";
            this.NGrpStdBtn.Size = new System.Drawing.Size(234, 71);
            this.NGrpStdBtn.TabIndex = 67;
            this.NGrpStdBtn.Text = "Non Group Students";
            this.NGrpStdBtn.UseVisualStyleBackColor = false;
            this.NGrpStdBtn.Click += new System.EventHandler(this.NGrpStdBtn_Click);
            // 
            // NGrpProjBtn
            // 
            this.NGrpProjBtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.NGrpProjBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.NGrpProjBtn.Location = new System.Drawing.Point(72, 199);
            this.NGrpProjBtn.Name = "NGrpProjBtn";
            this.NGrpProjBtn.Size = new System.Drawing.Size(234, 71);
            this.NGrpProjBtn.TabIndex = 66;
            this.NGrpProjBtn.Text = "Non Group Projects";
            this.NGrpProjBtn.UseVisualStyleBackColor = false;
            this.NGrpProjBtn.Click += new System.EventHandler(this.NGrpProjBtn_Click);
            // 
            // EvaluationStatusbtn
            // 
            this.EvaluationStatusbtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.EvaluationStatusbtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.EvaluationStatusbtn.Location = new System.Drawing.Point(391, 303);
            this.EvaluationStatusbtn.Name = "EvaluationStatusbtn";
            this.EvaluationStatusbtn.Size = new System.Drawing.Size(234, 71);
            this.EvaluationStatusbtn.TabIndex = 69;
            this.EvaluationStatusbtn.Text = "Evaluation Status";
            this.EvaluationStatusbtn.UseVisualStyleBackColor = false;
            this.EvaluationStatusbtn.Click += new System.EventHandler(this.EvaluationStatusbtn_Click);
            // 
            // NPrjAdvBtn
            // 
            this.NPrjAdvBtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.NPrjAdvBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.NPrjAdvBtn.Location = new System.Drawing.Point(72, 303);
            this.NPrjAdvBtn.Name = "NPrjAdvBtn";
            this.NPrjAdvBtn.Size = new System.Drawing.Size(234, 71);
            this.NPrjAdvBtn.TabIndex = 68;
            this.NPrjAdvBtn.Text = "Non Project Advisor";
            this.NPrjAdvBtn.UseVisualStyleBackColor = false;
            this.NPrjAdvBtn.Click += new System.EventHandler(this.NPrjAdvBtn_Click);
            // 
            // GrpEvaluations
            // 
            this.GrpEvaluations.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GrpEvaluations.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.GrpEvaluations.Location = new System.Drawing.Point(233, 406);
            this.GrpEvaluations.Name = "GrpEvaluations";
            this.GrpEvaluations.Size = new System.Drawing.Size(234, 71);
            this.GrpEvaluations.TabIndex = 70;
            this.GrpEvaluations.Text = "Group Wise Evaluations";
            this.GrpEvaluations.UseVisualStyleBackColor = false;
            this.GrpEvaluations.Click += new System.EventHandler(this.button6_Click);
            // 
            // ReportsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(715, 542);
            this.Controls.Add(this.GrpEvaluations);
            this.Controls.Add(this.EvaluationStatusbtn);
            this.Controls.Add(this.NPrjAdvBtn);
            this.Controls.Add(this.NGrpStdBtn);
            this.Controls.Add(this.NGrpProjBtn);
            this.Controls.Add(this.AllAdvisorsBtn);
            this.Controls.Add(this.AllStudentsBtn);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblViewLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReportsMenu";
            this.Text = "ReportsMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button AllStudentsBtn;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblViewLogo;
        private System.Windows.Forms.Button AllAdvisorsBtn;
        private System.Windows.Forms.Button NGrpStdBtn;
        private System.Windows.Forms.Button NGrpProjBtn;
        private System.Windows.Forms.Button EvaluationStatusbtn;
        private System.Windows.Forms.Button NPrjAdvBtn;
        private System.Windows.Forms.Button GrpEvaluations;
    }
}