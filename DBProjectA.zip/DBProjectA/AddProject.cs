﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class AddProject : Form
    {
        ProjectDL projectDL;
        public AddProject()
        {
            projectDL = new ProjectDL();
            InitializeComponent();
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AddProject_Load(object sender, EventArgs e)
        {

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            ProjectMenu projectMenu = new ProjectMenu();
            this.Close();
            projectMenu.Show();
        }

        private void ADDBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[2];
            textBoxes[0] = txtTitle;
            textBoxes[1] = txtDescription;

            Project project = new Project(txtDescription.Text, txtTitle.Text);
            if (projectDL.insert(project))
            {
                MessageBox.Show("Project added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add project.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void ProjectTitle_Click(object sender, EventArgs e)
        {

        }
    }
}
