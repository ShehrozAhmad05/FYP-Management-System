﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProjectA.DL
{
    public class CRUD
    {
        protected SqlConnection con;

        public CRUD() {
            con = Configuration.getInstance().getConnection();
        }
/*        private string insertParameters(Dictionary<int, string> columns, SqlCommand cmd)
        {
            string parameters = "";
            for (int i = 0; i < columns.Keys.Count; i++)
            {
                cmd.Parameters.AddWithValue("@" + i, columns[i]);
                parameters += "@" + i;
                if (i + 1 != columns.Keys.Count)
                    parameters += ",";
            }
            return parameters;

        }*/

        private string InsertParameters(Dictionary<int, string> columns, SqlCommand cmd)
        {
            string parameterNames = "";

            int keyCount = columns.Count;
            int currentIndex = 0;
            foreach (KeyValuePair<int, string> entry in columns)
            {
                string parameterName = "@" + entry.Key;
                string parameterValue = entry.Value;

                cmd.Parameters.AddWithValue(parameterName, parameterValue);
                parameterNames += parameterName;

                currentIndex++;
                if (currentIndex < keyCount)
                {
                    parameterNames += ",";
                }
            }

            return parameterNames;
        }



        /*        private string updateParameters(Dictionary<string, string> columns, SqlCommand cmd)
                {
                    string parameters = "";
                    int i = 0;
                    foreach (KeyValuePair<string, string> item in columns)
                    {
                        string parName = "@" + i;
                        i++;
                        string val = item.Value;

                        parameters += item.Key + "=" + parName + ",";
                        cmd.Parameters.AddWithValue(parName, val);
                    }
                    parameters = parameters.Remove(parameters.Length - 1);
                    return parameters;
                }
        */


        private string UpdateParameters(Dictionary<string, string> columns, SqlCommand cmd)
        {
            string parameterAssignments = "";
            int parameterIndex = 0;

            foreach (KeyValuePair<string, string> column in columns)
            {
                string parameterName = "@" + parameterIndex;
                parameterIndex++;
                string columnValue = column.Value;

                parameterAssignments += column.Key + " = " + parameterName + ",";
                cmd.Parameters.AddWithValue(parameterName, columnValue);
            }

            parameterAssignments = parameterAssignments.Remove(parameterAssignments.Length - 1);
            return parameterAssignments;
        }




        /*private string retrieveParameters(Dictionary<string, string> columns)
        {
            string parameters = "";

            // To get an IDictionaryEnumerator
            // for the SortedDictionary
            IDictionaryEnumerator myEnumerator =
                          columns.GetEnumerator();

            // If MoveNext passes the end of the
            // collection, the enumerator is positioned
            // after the last element in the collection
            // and MoveNext returns false.
            while (myEnumerator.MoveNext())
            {
                parameters += myEnumerator.Key + " AS " + myEnumerator.Value + ",";
            }
            *//*foreach (KeyValuePair<string, string> item in columns)
            {
            }*//*
            parameters = parameters.Remove(parameters.Length - 1);
            return parameters;

        }*/

        private string RetrieveParameters(Dictionary<string, string> columns)
        {
            string parameters = "";

            foreach (KeyValuePair<string, string> column in columns)
            {
                parameters += column.Key + " AS " + column.Value + ",";
            }

            if (!string.IsNullOrEmpty(parameters))
            {
                parameters = parameters.Remove(parameters.Length - 1);
            }

            return parameters;
        }


        /*protected string insertAndGet(string tableName, Dictionary<int, string> columnsInOrder, string returningColumn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = insertParameters(columnsInOrder, cmd);
                string query = "INSERT " + tableName + " OUTPUT INSERTED." + returningColumn + " values (" + parameters + ")";
                cmd.Connection = con;
                cmd.CommandText = query;
                string output = cmd.ExecuteScalar().ToString();
                return output;
            }
            catch (SqlException e)
            {
                return null;
            }
        }*/

        protected string InsertAndGet(string tableName, Dictionary<int, string> columnsInOrder, string returningColumn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = InsertParameters(columnsInOrder, cmd);
                string query = "INSERT INTO " + tableName + " OUTPUT INSERTED." + returningColumn + " VALUES (" + parameters + ")";
                cmd.Connection = con;
                cmd.CommandText = query;
                string output = cmd.ExecuteScalar()?.ToString();
                return output;
            }
            catch (SqlException ex)
            {
                return null;
            }
        }

        /*protected bool insert(string tableName, Dictionary<int, string> columnsInOrder)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = insertParameters(columnsInOrder, cmd);
                string query = "INSERT INTO " + tableName + " values (" + parameters + ")";
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException e)
            {
                return false;
            }
        }*/

        protected bool Insert(string tableName, Dictionary<int, string> columnsInOrder)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = InsertParameters(columnsInOrder, cmd);
                string query = "INSERT INTO " + tableName + " VALUES (" + parameters + ")";
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
        }


        /*        protected bool update(string tableName, Dictionary<string, string> columns, string conditionColumn, string conditionValue)
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();
                        string parameters = updateParameters(columns, cmd);
                        string query = "UPDATE " + tableName + " set " + parameters + " where " + conditionColumn + " = @value";
                        cmd.Parameters.AddWithValue("@value", conditionValue);
                        cmd.Connection = con;
                        cmd.CommandText = query;
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                    catch (SqlException e)
                    {
                        return false;
                    }
                }
        */

        protected bool Update(string tableName, Dictionary<string, string> columns, string conditionColumn, string conditionValue)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string setClause = UpdateParameters(columns, cmd);
                string query = $"UPDATE {tableName} SET {setClause} WHERE {conditionColumn} = @value";
                cmd.Parameters.AddWithValue("@value", conditionValue);
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
        }

        /*protected DataTable retrieve(string tableName, Dictionary<string, string> columns, string conditionColumn, string conditionValue)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = retrieveParameters(columns);
                string query = "SELECT " + parameters + " FROM " + tableName + " WHERE " + conditionColumn + "= @conditionValue";
                cmd.Parameters.AddWithValue("@conditionValue", conditionValue);
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException e)
            {
                return null;
            }
        }*/

        protected DataTable Retrieve(string tableName, Dictionary<string, string> columns, string conditionColumn, string conditionValue)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string selectClause = RetrieveParameters(columns);
                string query = $"SELECT {selectClause} FROM {tableName} WHERE {conditionColumn} = @conditionValue";
                cmd.Parameters.AddWithValue("@conditionValue", conditionValue);
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                return dataTable;
            }
            catch (SqlException ex)
            {
                return null;
            }
        }


        /*protected DataTable retrieve(string tableName, Dictionary<string, string> columns)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = retrieveParameters(columns);
                string query = "SELECT " + parameters + " FROM " + tableName;
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException e)
            {
                return null;
            }
        }*/

        protected DataTable Retrieve(string tableName, Dictionary<string, string> columns)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string selectClause = RetrieveParameters(columns);
                string query = $"SELECT {selectClause} FROM {tableName}";
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                return dataTable;
            }
            catch (SqlException ex)
            {
                return null;
            }
        }


        /*protected bool delete(string tableName, string conditionColumn, string conditionValue)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string query = "DELETE " + tableName + " where " + conditionColumn + " = @value";
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@value", conditionValue);
                cmd.ExecuteNonQuery();
                return true;
            }

            catch (SqlException e)
            {
                return false;
            }
        }*/

        protected bool Delete(string tableName, string conditionColumn, string conditionValue)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string query = $"DELETE FROM {tableName} WHERE {conditionColumn} = @value";
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@value", conditionValue);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
        }


        /*protected DataTable retrieveWithjoin(string firstTableName, string secondTableName, Dictionary<string, string> columns, string joinConditionColumn1, string joinConditionColumn2)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string parameters = retrieveParameters(columns);
                string query = "SELECT " + parameters + " FROM " + firstTableName +
                                " JOIN " + secondTableName + " ON " + joinConditionColumn1 + " = " + joinConditionColumn2;
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException e)
            {
                return null;
            }
        }*/

        protected DataTable RetrieveWithJoin(string firstTableName, string secondTableName, Dictionary<string, string> columns, string joinConditionColumn1, string joinConditionColumn2)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                string selectClause = RetrieveParameters(columns);
                string query = $"SELECT {selectClause} FROM {firstTableName} JOIN {secondTableName} ON {joinConditionColumn1} = {joinConditionColumn2}";
                cmd.Connection = con;
                cmd.CommandText = query;
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                return dataTable;
            }
            catch (SqlException ex)
            {
                return null;
            }
        }

    }
}
