﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ViewAdvisor : Form
    {
        AdvisorDL advisorDL;
        EditAdvisor formUpdate;

        public ViewAdvisor()
        {
            advisorDL = new AdvisorDL();
            InitializeComponent();
        }

        private void ViewAdvisor_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!advisorDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            DGV.DataSource = advisorDL.getList();
            changeDGVorder();
        }

        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["FirstName"].DisplayIndex = 1;
            DGV.Columns["LastName"].DisplayIndex = 2;
            DGV.Columns["Contact"].DisplayIndex = 3;
            DGV.Columns["Email"].DisplayIndex = 4;
            DGV.Columns["Designation"].DisplayIndex = 5;
            DGV.Columns["Salary"].DisplayIndex = 6;
            DGV.Columns["DateOfBirth"].DisplayIndex = 7;
            DGV.Columns["Gender"].DisplayIndex = 8;
            DGV.Columns["FirstName"].HeaderText = "First Name";
            DGV.Columns["LastName"].HeaderText = "Last Name";
            DGV.Columns["DateOfBirth"].HeaderText = "Date Of Birth";
        }

        private void updateDGV()
        {
            advisorDL.fetchRecords();
            DGV.DataSource = advisorDL.getList();
            changeDGVorder();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            string designation = DGV.Rows[rowIdx].Cells["Designation"].Value.ToString();
            string firstName = DGV.Rows[rowIdx].Cells["FirstName"].Value.ToString();
            string lastName = DGV.Rows[rowIdx].Cells["LastName"].Value.ToString();
            string contact = DGV.Rows[rowIdx].Cells["Contact"].Value.ToString();
            string email = DGV.Rows[rowIdx].Cells["Email"].Value.ToString();
            string dob = DGV.Rows[rowIdx].Cells["DateOfBirth"].Value.ToString();
            string gender = DGV.Rows[rowIdx].Cells["Gender"].Value.ToString();
            string id = DGV.Rows[rowIdx].Cells["Id"].Value.ToString();
            string salary = DGV.Rows[rowIdx].Cells["Salary"].Value.ToString();
            Advisor adv = new Advisor(id, firstName, lastName, contact, email, dob, gender, designation, salary);
            formUpdate = new EditAdvisor(adv);
            formUpdate.onSuccessUpdate += new EventHandler(onSuccessUpdate);
            formUpdate.ShowDialog();
        }

        private void onSuccessUpdate(object sender, EventArgs e)
        {
            updateDGV();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            AdvisorMenu advisorMenu = new AdvisorMenu();
            this.Close();
            advisorMenu.Show();

        }
    }
}
