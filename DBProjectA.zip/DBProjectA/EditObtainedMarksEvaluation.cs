﻿using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EditObtainedMarksEvaluation : Form
    {
        string groupId;
        string evaluationId;
        GroupEvaluationDL groupEvaluationDL;
        public event EventHandler onSuccess;
        public EditObtainedMarksEvaluation(string groupId, string evaluationId, string totalMarks, string weightage, string obtainedMarks)
        {
            InitializeComponent();
            this.txtTotalMarks.Text = totalMarks;
            this.txtWeightage.Text = weightage;
            this.txtObtainedMarks.Text = obtainedMarks;
            this.txtTotalMarks.ReadOnly = true;
            this.txtWeightage.ReadOnly = true;
            this.evaluationId = evaluationId;
            this.groupId = groupId;
            groupEvaluationDL = new GroupEvaluationDL();
        }

        private void EditObtainedMarksEvaluation_Load(object sender, EventArgs e)
        {

        }

        private void Evaluatebtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[3];
            textBoxes[0] = txtObtainedMarks;

            if (int.Parse(txtObtainedMarks.Text) <= int.Parse(txtTotalMarks.Text))
            {
                if (!groupEvaluationDL.updateObatinedMarks(groupId, evaluationId, txtObtainedMarks.Text))
                {
                    MessageBox.Show("Failed To Update.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {
                    MessageBox.Show("Data Has Been Successfully Updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    onSuccess?.Invoke(this, null);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Obtained Marks Must Be Smaller Than Total Marks.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
