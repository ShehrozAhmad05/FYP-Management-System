﻿namespace DBProjectA
{
    partial class EditObtainedMarksEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Evaluatebtn = new System.Windows.Forms.Button();
            this.txtWeightage = new System.Windows.Forms.TextBox();
            this.lblWeightage = new System.Windows.Forms.Label();
            this.txtTotalMarks = new System.Windows.Forms.TextBox();
            this.txtObtainedMarks = new System.Windows.Forms.TextBox();
            this.lblTotalMarks = new System.Windows.Forms.Label();
            this.lblEName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.button1.Location = new System.Drawing.Point(140, 381);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 44);
            this.button1.TabIndex = 113;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Evaluatebtn
            // 
            this.Evaluatebtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.Evaluatebtn.Location = new System.Drawing.Point(275, 381);
            this.Evaluatebtn.Margin = new System.Windows.Forms.Padding(4);
            this.Evaluatebtn.Name = "Evaluatebtn";
            this.Evaluatebtn.Size = new System.Drawing.Size(123, 44);
            this.Evaluatebtn.TabIndex = 112;
            this.Evaluatebtn.Text = "Update";
            this.Evaluatebtn.UseVisualStyleBackColor = true;
            this.Evaluatebtn.Click += new System.EventHandler(this.Evaluatebtn_Click);
            // 
            // txtWeightage
            // 
            this.txtWeightage.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtWeightage.Location = new System.Drawing.Point(141, 209);
            this.txtWeightage.Margin = new System.Windows.Forms.Padding(4);
            this.txtWeightage.Name = "txtWeightage";
            this.txtWeightage.Size = new System.Drawing.Size(257, 33);
            this.txtWeightage.TabIndex = 111;
            // 
            // lblWeightage
            // 
            this.lblWeightage.AutoSize = true;
            this.lblWeightage.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblWeightage.Location = new System.Drawing.Point(137, 182);
            this.lblWeightage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWeightage.Name = "lblWeightage";
            this.lblWeightage.Size = new System.Drawing.Size(115, 23);
            this.lblWeightage.TabIndex = 110;
            this.lblWeightage.Text = "Weightage";
            // 
            // txtTotalMarks
            // 
            this.txtTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtTotalMarks.Location = new System.Drawing.Point(141, 101);
            this.txtTotalMarks.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalMarks.Name = "txtTotalMarks";
            this.txtTotalMarks.Size = new System.Drawing.Size(257, 33);
            this.txtTotalMarks.TabIndex = 109;
            // 
            // txtObtainedMarks
            // 
            this.txtObtainedMarks.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.txtObtainedMarks.Location = new System.Drawing.Point(141, 316);
            this.txtObtainedMarks.Margin = new System.Windows.Forms.Padding(4);
            this.txtObtainedMarks.Name = "txtObtainedMarks";
            this.txtObtainedMarks.Size = new System.Drawing.Size(257, 33);
            this.txtObtainedMarks.TabIndex = 108;
            // 
            // lblTotalMarks
            // 
            this.lblTotalMarks.AutoSize = true;
            this.lblTotalMarks.Font = new System.Drawing.Font("Lucida Sans", 12F);
            this.lblTotalMarks.Location = new System.Drawing.Point(136, 71);
            this.lblTotalMarks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalMarks.Name = "lblTotalMarks";
            this.lblTotalMarks.Size = new System.Drawing.Size(123, 23);
            this.lblTotalMarks.TabIndex = 107;
            this.lblTotalMarks.Text = "Total Marks";
            // 
            // lblEName
            // 
            this.lblEName.AutoSize = true;
            this.lblEName.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEName.Location = new System.Drawing.Point(136, 286);
            this.lblEName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEName.Name = "lblEName";
            this.lblEName.Size = new System.Drawing.Size(160, 23);
            this.lblEName.TabIndex = 106;
            this.lblEName.Text = "ObtainedMarks";
            // 
            // EditObtainedMarksEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(538, 500);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Evaluatebtn);
            this.Controls.Add(this.txtWeightage);
            this.Controls.Add(this.lblWeightage);
            this.Controls.Add(this.txtTotalMarks);
            this.Controls.Add(this.txtObtainedMarks);
            this.Controls.Add(this.lblTotalMarks);
            this.Controls.Add(this.lblEName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditObtainedMarksEvaluation";
            this.Text = "EditObtainedMarksEvaluation";
            this.Load += new System.EventHandler(this.EditObtainedMarksEvaluation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Evaluatebtn;
        private System.Windows.Forms.TextBox txtWeightage;
        private System.Windows.Forms.Label lblWeightage;
        private System.Windows.Forms.TextBox txtTotalMarks;
        private System.Windows.Forms.TextBox txtObtainedMarks;
        private System.Windows.Forms.Label lblTotalMarks;
        private System.Windows.Forms.Label lblEName;
    }
}