﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class MarkEvaluation : Form
    {
        GroupProjectDL groupProjectDL;
        ProjectDL projectDL;
        public MarkEvaluation()
        {
            groupProjectDL = new GroupProjectDL();
            projectDL = new ProjectDL();
            InitializeComponent();
        }

        private void MarkEvaluation_Load(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!groupProjectDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            DGV.DataSource = groupProjectDL.getList();
            changeDGVorder();
        }

        private void changeDGVorder()
        {
            
            DataTable dt = new DataTable();
            List<GroupProject> lst = (List<GroupProject>)DGV.DataSource;
            dt.Columns.Add("GroupId", typeof(string));
            dt.Columns.Add("ProjectId", typeof(string));
            dt.Columns.Add("projectTitle", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("AssignmentDate", typeof(string));
            foreach (var item in lst)
            {
                string projectId = item.ProjectId;
                projectDL.fetchById(projectId);
                List<Project> lst1 = projectDL.getList();
                string title = "";
                string description = "";
                foreach (var item1 in lst1)
                {
                    title = item1.Title;
                    description = item1.Description;
                }
                DataRow dr = dt.NewRow();
                dr["GroupId"] = item.GroupId;
                dr["ProjectId"] = projectId;
                dr["projectTitle"] = title;
                dr["Description"] = description;
                dr["AssignmentDate"] = item.AssignmentDate;
                dt.Rows.Add(dr);
            }

            DGV.DataSource = dt;
            DGV.Columns["GroupId"].DisplayIndex = 0;
            DGV.Columns["ProjectId"].DisplayIndex = 1;
            DGV.Columns["projectTitle"].DisplayIndex = 2;
            DGV.Columns["Description"].DisplayIndex = 3;
            DGV.Columns["AssignmentDate"].DisplayIndex = 4;
        }

        private void SelectBtn_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            string groupId = DGV.Rows[rowIdx].Cells["GroupId"].Value.ToString();
            SelectEvaluation selectEvaluation = new SelectEvaluation(groupId);
            selectEvaluation.Show();
            this.Close();

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            systemMenu.Show();
            this.Close();
        }
    }
}
