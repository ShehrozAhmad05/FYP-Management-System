﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class ViewForm : Form
    {
        StudentDL studentDL;
        EditForm formUpdate;

        public ViewForm()
        {
            studentDL = new StudentDL();
            InitializeComponent();
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            
        }

        private void onSuccessUpdate(object sender, EventArgs e)
        {
            updateDGV();
        }

        private void updateDGV()
        {
            studentDL.fetchRecords();
            DGV.DataSource = studentDL.getList();
            changeDGVorder();
        }

        private void ViewForm_Load(object sender, EventArgs e)
        {
            
        }

        private void changeDGVorder()
        {
            DGV.AutoGenerateColumns = false;
            DGV.Columns["Id"].DisplayIndex = 0;
            DGV.Columns["RegistrationNumber"].DisplayIndex = 1;
            DGV.Columns["FirstName"].DisplayIndex = 2;
            DGV.Columns["LastName"].DisplayIndex = 3;
            DGV.Columns["Contact"].DisplayIndex = 4;
            DGV.Columns["Email"].DisplayIndex = 5;
            DGV.Columns["DateOfBirth"].DisplayIndex = 6;
            DGV.Columns["Gender"].DisplayIndex = 7;
            DGV.Columns["RegistrationNumber"].HeaderText = "Registration Number";
            DGV.Columns["FirstName"].HeaderText = "First Name";
            DGV.Columns["LastName"].HeaderText = "Last Name";
            DGV.Columns["DateOfBirth"].HeaderText = "Date Of Birth";
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            
        }

        private void pbCloseButton2_Click_1(object sender, EventArgs e)
        {
            StudentForm form = new StudentForm();
            this.Close();
            form.Show();
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ViewForm_Load_1(object sender, EventArgs e)
        {
            DGV.MultiSelect = false;
            DGV.ScrollBars = ScrollBars.None;
            if (!studentDL.fetchRecords())
            {
                MessageBox.Show("Failed to retreive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            DGV.DataSource = studentDL.getList();
            changeDGVorder();
        }

        private void UpdateBtn_Click_1(object sender, EventArgs e)
        {
            if (DGV.Rows.Count == 0)
                return;
            int rowIdx = DGV.SelectedRows[0].Index;
            string regNo = DGV.Rows[rowIdx].Cells["RegistrationNumber"].Value.ToString();
            string firstName = DGV.Rows[rowIdx].Cells["FirstName"].Value.ToString();
            string lastName = DGV.Rows[rowIdx].Cells["LastName"].Value.ToString();
            string contact = DGV.Rows[rowIdx].Cells["Contact"].Value.ToString();
            string email = DGV.Rows[rowIdx].Cells["Email"].Value.ToString();
            string dob = DGV.Rows[rowIdx].Cells["DateOfBirth"].Value.ToString();
            string gender = DGV.Rows[rowIdx].Cells["Gender"].Value.ToString();
            string id = DGV.Rows[rowIdx].Cells["Id"].Value.ToString();
            Student std = new Student(id, firstName, lastName, contact, email, dob
                                , gender, regNo);
            formUpdate = new EditForm(std);
            formUpdate.onSuccessUpdate += new EventHandler(onSuccessUpdate);
            formUpdate.ShowDialog();
        }
    }
}
