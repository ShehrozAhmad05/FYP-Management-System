﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EditForm : Form
    {
        Student student;
        StudentDL studentDL;
        public event EventHandler onSuccessUpdate;
        public EditForm(Student student)
        {
            InitializeComponent();
            this.student = student;
            studentDL = new StudentDL();
            txtFirstName.Text = student.FirstName;
            txtLastName.Text = student.LastName;
            txtContact.Text = student.Contact;
            txtEmail.Text = student.Email;
            txtRegNo.Text = student.RegistrationNumber;
            cmbGender.Text = student.Gender;
            dtDOB.Text = student.DateOfBirth;
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {


            TextBox[] textBoxes = new TextBox[5];
            textBoxes[0] = txtFirstName;
            textBoxes[1] = txtLastName;
            textBoxes[2] = txtContact;
            textBoxes[3] = txtEmail;
            textBoxes[4] = txtRegNo;
            student.FirstName = txtFirstName.Text;
            student.LastName = txtLastName.Text;
            student.Contact = txtContact.Text;
            student.Email = txtEmail.Text;
            student.DateOfBirth = student.parseDate(dtDOB.Text);
            student.Gender = cmbGender.Text;
            student.RegistrationNumber = txtRegNo.Text;

            if (studentDL.update(student))
            {
                MessageBox.Show("Record Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                onSuccessUpdate?.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill the correct information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Gender_Click(object sender, EventArgs e)
        {

        }

        private void Contact_Click(object sender, EventArgs e)
        {

        }

        private void LastName_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void EditForm_Load(object sender, EventArgs e)
        {

        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {

            ViewForm viewForm = new ViewForm();
            this.Close();
            viewForm.Show();
        }

        private void lblEditLogo_Click(object sender, EventArgs e)
        {

        }
    }
}
