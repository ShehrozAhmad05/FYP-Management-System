﻿namespace DBProjectA
{
    partial class AddProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.ProjectDesc = new System.Windows.Forms.Label();
            this.ProjectTitle = new System.Windows.Forms.Label();
            this.lblAddprjLogo = new System.Windows.Forms.Label();
            this.ADDBtn = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.txtDescription.Location = new System.Drawing.Point(272, 299);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(293, 107);
            this.txtDescription.TabIndex = 86;
            this.txtDescription.TextChanged += new System.EventHandler(this.txtLastName_TextChanged);
            // 
            // txtTitle
            // 
            this.txtTitle.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.txtTitle.Location = new System.Drawing.Point(272, 180);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(293, 35);
            this.txtTitle.TabIndex = 85;
            this.txtTitle.TextChanged += new System.EventHandler(this.txtTitle_TextChanged);
            // 
            // ProjectDesc
            // 
            this.ProjectDesc.AutoSize = true;
            this.ProjectDesc.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.ProjectDesc.Location = new System.Drawing.Point(267, 269);
            this.ProjectDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ProjectDesc.Name = "ProjectDesc";
            this.ProjectDesc.Size = new System.Drawing.Size(236, 27);
            this.ProjectDesc.TabIndex = 84;
            this.ProjectDesc.Text = "Project Description";
            this.ProjectDesc.Click += new System.EventHandler(this.label1_Click);
            // 
            // ProjectTitle
            // 
            this.ProjectTitle.AutoSize = true;
            this.ProjectTitle.Font = new System.Drawing.Font("Lucida Sans", 14F);
            this.ProjectTitle.Location = new System.Drawing.Point(267, 150);
            this.ProjectTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ProjectTitle.Name = "ProjectTitle";
            this.ProjectTitle.Size = new System.Drawing.Size(151, 27);
            this.ProjectTitle.TabIndex = 83;
            this.ProjectTitle.Text = "Project Title";
            this.ProjectTitle.Click += new System.EventHandler(this.ProjectTitle_Click);
            // 
            // lblAddprjLogo
            // 
            this.lblAddprjLogo.AutoSize = true;
            this.lblAddprjLogo.BackColor = System.Drawing.Color.White;
            this.lblAddprjLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddprjLogo.Location = new System.Drawing.Point(13, 9);
            this.lblAddprjLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddprjLogo.Name = "lblAddprjLogo";
            this.lblAddprjLogo.Size = new System.Drawing.Size(185, 40);
            this.lblAddprjLogo.TabIndex = 81;
            this.lblAddprjLogo.Text = "ADD PROJECT";
            // 
            // ADDBtn
            // 
            this.ADDBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.ADDBtn.Location = new System.Drawing.Point(343, 458);
            this.ADDBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ADDBtn.Name = "ADDBtn";
            this.ADDBtn.Size = new System.Drawing.Size(146, 49);
            this.ADDBtn.TabIndex = 87;
            this.ADDBtn.Text = "Add";
            this.ADDBtn.UseVisualStyleBackColor = true;
            this.ADDBtn.Click += new System.EventHandler(this.ADDBtn_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(812, 2);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 82;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // AddProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(866, 615);
            this.Controls.Add(this.ADDBtn);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.ProjectDesc);
            this.Controls.Add(this.ProjectTitle);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblAddprjLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddProject";
            this.Text = "AddProject";
            this.Load += new System.EventHandler(this.AddProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label ProjectDesc;
        private System.Windows.Forms.Label ProjectTitle;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblAddprjLogo;
        private System.Windows.Forms.Button ADDBtn;
    }
}