﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EvaluationMenu : Form
    {
        public EvaluationMenu()
        {
            InitializeComponent();
        }

        private void CreateEvalBtn_Click(object sender, EventArgs e)
        {
            CreateEvaluation createEvaluation = new CreateEvaluation();
            this.Close();
            createEvaluation.Show();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();
        }

        private void ManageEvalBtn_Click(object sender, EventArgs e)
        {
            ManageEvaluation manageEvaluation = new ManageEvaluation();
            this.Close();
            manageEvaluation.Show();
        }

        private void EvaluationMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
