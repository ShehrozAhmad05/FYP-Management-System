﻿namespace DBProjectA
{
    partial class CreateGroup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCreatelogo = new System.Windows.Forms.Label();
            this.DGV = new System.Windows.Forms.DataGridView();
            this.CreateBtn = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.selectlbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCreatelogo
            // 
            this.lblCreatelogo.AutoSize = true;
            this.lblCreatelogo.BackColor = System.Drawing.Color.White;
            this.lblCreatelogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreatelogo.Location = new System.Drawing.Point(13, 9);
            this.lblCreatelogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCreatelogo.Name = "lblCreatelogo";
            this.lblCreatelogo.Size = new System.Drawing.Size(217, 40);
            this.lblCreatelogo.TabIndex = 54;
            this.lblCreatelogo.Text = "CREATE GROUPS";
            // 
            // DGV
            // 
            this.DGV.AllowUserToAddRows = false;
            this.DGV.AllowUserToDeleteRows = false;
            this.DGV.AllowUserToResizeRows = false;
            this.DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV.BackgroundColor = System.Drawing.Color.LightCyan;
            this.DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV.ColumnHeadersHeight = 22;
            this.DGV.EnableHeadersVisualStyles = false;
            this.DGV.Location = new System.Drawing.Point(1, 101);
            this.DGV.Name = "DGV";
            this.DGV.ReadOnly = true;
            this.DGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV.RowHeadersVisible = false;
            this.DGV.RowHeadersWidth = 51;
            this.DGV.RowTemplate.Height = 24;
            this.DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV.Size = new System.Drawing.Size(1046, 432);
            this.DGV.TabIndex = 63;
            this.DGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_CellClick);
            this.DGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_CellContentClick);
            // 
            // CreateBtn
            // 
            this.CreateBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.CreateBtn.Location = new System.Drawing.Point(454, 550);
            this.CreateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.CreateBtn.Name = "CreateBtn";
            this.CreateBtn.Size = new System.Drawing.Size(146, 49);
            this.CreateBtn.TabIndex = 93;
            this.CreateBtn.Text = "Create";
            this.CreateBtn.UseVisualStyleBackColor = true;
            this.CreateBtn.Click += new System.EventHandler(this.CreateBtn_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(994, 3);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 55;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // selectlbl
            // 
            this.selectlbl.AutoSize = true;
            this.selectlbl.Font = new System.Drawing.Font("Lucida Fax", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectlbl.Location = new System.Drawing.Point(419, 65);
            this.selectlbl.Name = "selectlbl";
            this.selectlbl.Size = new System.Drawing.Size(238, 33);
            this.selectlbl.TabIndex = 94;
            this.selectlbl.Text = "Select Students";
            // 
            // CreateGroup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1049, 624);
            this.Controls.Add(this.selectlbl);
            this.Controls.Add(this.CreateBtn);
            this.Controls.Add(this.DGV);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblCreatelogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CreateGroup";
            this.Text = "CreateGroup";
            this.Load += new System.EventHandler(this.CreateGroup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblCreatelogo;
        private System.Windows.Forms.DataGridView DGV;
        private System.Windows.Forms.Button CreateBtn;
        private System.Windows.Forms.Label selectlbl;
    }
}