﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class GroupMenu : Form
    {
        public GroupMenu()
        {
            InitializeComponent();
        }

        private void CreateGrpBtn_Click(object sender, EventArgs e)
        {
            CreateGroup createGroup = new CreateGroup();
            this.Close();
            createGroup.Show();
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            SystemMenu systemMenu = new SystemMenu();
            this.Close();
            systemMenu.Show();
        }

        private void ViewGrpBtn_Click(object sender, EventArgs e)
        {
            ViewGroups viewGroups=new ViewGroups();
            this.Close();
            viewGroups.Show();
        }

        private void BtnAssignProject_Click(object sender, EventArgs e)
        {
            AssignProject assignProject = new AssignProject();
            this.Close();
            assignProject.Show();

        }
    }
}
