﻿namespace DBProjectA
{
    partial class SystemMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExitBtn = new System.Windows.Forms.Button();
            this.ProjectBtn = new System.Windows.Forms.Button();
            this.GroupsBtn = new System.Windows.Forms.Button();
            this.AdvisorBtn = new System.Windows.Forms.Button();
            this.StudentBtn = new System.Windows.Forms.Button();
            this.lblFYPLogo = new System.Windows.Forms.Label();
            this.EvaluationBtn = new System.Windows.Forms.Button();
            this.btnGrpEvaluations = new System.Windows.Forms.Button();
            this.ReportBtn = new System.Windows.Forms.Button();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            this.pbCircleLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCircleLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // ExitBtn
            // 
            this.ExitBtn.BackColor = System.Drawing.Color.Red;
            this.ExitBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.Location = new System.Drawing.Point(576, 502);
            this.ExitBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(243, 79);
            this.ExitBtn.TabIndex = 9;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = false;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // ProjectBtn
            // 
            this.ProjectBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ProjectBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProjectBtn.Location = new System.Drawing.Point(202, 271);
            this.ProjectBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ProjectBtn.Name = "ProjectBtn";
            this.ProjectBtn.Size = new System.Drawing.Size(243, 79);
            this.ProjectBtn.TabIndex = 8;
            this.ProjectBtn.Text = "Projects";
            this.ProjectBtn.UseVisualStyleBackColor = false;
            this.ProjectBtn.Click += new System.EventHandler(this.ProjectBtn_Click);
            // 
            // GroupsBtn
            // 
            this.GroupsBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.GroupsBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupsBtn.Location = new System.Drawing.Point(576, 271);
            this.GroupsBtn.Margin = new System.Windows.Forms.Padding(4);
            this.GroupsBtn.Name = "GroupsBtn";
            this.GroupsBtn.Size = new System.Drawing.Size(243, 79);
            this.GroupsBtn.TabIndex = 7;
            this.GroupsBtn.Text = "Groups";
            this.GroupsBtn.UseVisualStyleBackColor = false;
            this.GroupsBtn.Click += new System.EventHandler(this.GroupsBtn_Click);
            // 
            // AdvisorBtn
            // 
            this.AdvisorBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.AdvisorBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdvisorBtn.Location = new System.Drawing.Point(576, 156);
            this.AdvisorBtn.Margin = new System.Windows.Forms.Padding(4);
            this.AdvisorBtn.Name = "AdvisorBtn";
            this.AdvisorBtn.Size = new System.Drawing.Size(243, 79);
            this.AdvisorBtn.TabIndex = 6;
            this.AdvisorBtn.Text = "Advisor";
            this.AdvisorBtn.UseVisualStyleBackColor = false;
            this.AdvisorBtn.Click += new System.EventHandler(this.AdvisorBtn_Click);
            // 
            // StudentBtn
            // 
            this.StudentBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.StudentBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentBtn.Location = new System.Drawing.Point(202, 156);
            this.StudentBtn.Margin = new System.Windows.Forms.Padding(4);
            this.StudentBtn.Name = "StudentBtn";
            this.StudentBtn.Size = new System.Drawing.Size(243, 79);
            this.StudentBtn.TabIndex = 5;
            this.StudentBtn.Text = "Student";
            this.StudentBtn.UseVisualStyleBackColor = false;
            this.StudentBtn.Click += new System.EventHandler(this.StudentBtn_Click);
            // 
            // lblFYPLogo
            // 
            this.lblFYPLogo.AutoSize = true;
            this.lblFYPLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFYPLogo.Location = new System.Drawing.Point(91, 59);
            this.lblFYPLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFYPLogo.Name = "lblFYPLogo";
            this.lblFYPLogo.Size = new System.Drawing.Size(334, 40);
            this.lblFYPLogo.TabIndex = 10;
            this.lblFYPLogo.Text = "FYP Management System";
            // 
            // EvaluationBtn
            // 
            this.EvaluationBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.EvaluationBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EvaluationBtn.Location = new System.Drawing.Point(202, 387);
            this.EvaluationBtn.Margin = new System.Windows.Forms.Padding(4);
            this.EvaluationBtn.Name = "EvaluationBtn";
            this.EvaluationBtn.Size = new System.Drawing.Size(243, 79);
            this.EvaluationBtn.TabIndex = 53;
            this.EvaluationBtn.Text = "Evaluation";
            this.EvaluationBtn.UseVisualStyleBackColor = false;
            this.EvaluationBtn.Click += new System.EventHandler(this.EvaluationBtn_Click);
            // 
            // btnGrpEvaluations
            // 
            this.btnGrpEvaluations.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnGrpEvaluations.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrpEvaluations.Location = new System.Drawing.Point(576, 387);
            this.btnGrpEvaluations.Margin = new System.Windows.Forms.Padding(4);
            this.btnGrpEvaluations.Name = "btnGrpEvaluations";
            this.btnGrpEvaluations.Size = new System.Drawing.Size(243, 79);
            this.btnGrpEvaluations.TabIndex = 54;
            this.btnGrpEvaluations.Text = "Group Evaluations";
            this.btnGrpEvaluations.UseVisualStyleBackColor = false;
            this.btnGrpEvaluations.Click += new System.EventHandler(this.btnGrpEvaluations_Click);
            // 
            // ReportBtn
            // 
            this.ReportBtn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ReportBtn.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportBtn.Location = new System.Drawing.Point(202, 502);
            this.ReportBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ReportBtn.Name = "ReportBtn";
            this.ReportBtn.Size = new System.Drawing.Size(243, 79);
            this.ReportBtn.TabIndex = 55;
            this.ReportBtn.Text = "Generate Reports";
            this.ReportBtn.UseVisualStyleBackColor = false;
            this.ReportBtn.Click += new System.EventHandler(this.ReportBtn_Click);
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(970, 4);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 52;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // pbCircleLogo
            // 
            this.pbCircleLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbCircleLogo.Image = global::DBProjectA.Properties.Resources.project;
            this.pbCircleLogo.Location = new System.Drawing.Point(13, 13);
            this.pbCircleLogo.Margin = new System.Windows.Forms.Padding(4);
            this.pbCircleLogo.Name = "pbCircleLogo";
            this.pbCircleLogo.Size = new System.Drawing.Size(75, 69);
            this.pbCircleLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCircleLogo.TabIndex = 11;
            this.pbCircleLogo.TabStop = false;
            // 
            // SystemMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1027, 677);
            this.ControlBox = false;
            this.Controls.Add(this.ReportBtn);
            this.Controls.Add(this.btnGrpEvaluations);
            this.Controls.Add(this.EvaluationBtn);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.pbCircleLogo);
            this.Controls.Add(this.lblFYPLogo);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.ProjectBtn);
            this.Controls.Add(this.GroupsBtn);
            this.Controls.Add(this.AdvisorBtn);
            this.Controls.Add(this.StudentBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SystemMenu";
            this.Text = "SystemMenu";
            this.Load += new System.EventHandler(this.SystemMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCircleLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button ProjectBtn;
        private System.Windows.Forms.Button GroupsBtn;
        private System.Windows.Forms.Button AdvisorBtn;
        private System.Windows.Forms.Button StudentBtn;
        private System.Windows.Forms.PictureBox pbCircleLogo;
        private System.Windows.Forms.Label lblFYPLogo;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Button EvaluationBtn;
        private System.Windows.Forms.Button btnGrpEvaluations;
        private System.Windows.Forms.Button ReportBtn;
    }
}