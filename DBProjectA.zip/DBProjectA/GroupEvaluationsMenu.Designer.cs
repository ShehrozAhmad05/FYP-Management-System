﻿namespace DBProjectA
{
    partial class GroupEvaluationsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ViewAdvBtn = new System.Windows.Forms.Button();
            this.BtnMarkEvaluations = new System.Windows.Forms.Button();
            this.lblViewLogo = new System.Windows.Forms.Label();
            this.pbCloseButton2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewAdvBtn
            // 
            this.ViewAdvBtn.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.ViewAdvBtn.Location = new System.Drawing.Point(411, 184);
            this.ViewAdvBtn.Name = "ViewAdvBtn";
            this.ViewAdvBtn.Size = new System.Drawing.Size(228, 89);
            this.ViewAdvBtn.TabIndex = 65;
            this.ViewAdvBtn.Text = "Update Evaluation";
            this.ViewAdvBtn.UseVisualStyleBackColor = true;
            this.ViewAdvBtn.Click += new System.EventHandler(this.ViewAdvBtn_Click);
            // 
            // BtnMarkEvaluations
            // 
            this.BtnMarkEvaluations.Font = new System.Drawing.Font("Lucida Sans", 13F);
            this.BtnMarkEvaluations.Location = new System.Drawing.Point(76, 184);
            this.BtnMarkEvaluations.Name = "BtnMarkEvaluations";
            this.BtnMarkEvaluations.Size = new System.Drawing.Size(228, 89);
            this.BtnMarkEvaluations.TabIndex = 64;
            this.BtnMarkEvaluations.Text = "Mark Evaluation";
            this.BtnMarkEvaluations.UseVisualStyleBackColor = true;
            this.BtnMarkEvaluations.Click += new System.EventHandler(this.BtnMarkEvaluations_Click);
            // 
            // lblViewLogo
            // 
            this.lblViewLogo.AutoSize = true;
            this.lblViewLogo.BackColor = System.Drawing.Color.White;
            this.lblViewLogo.Font = new System.Drawing.Font("Bernard MT Condensed", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewLogo.Location = new System.Drawing.Point(13, 9);
            this.lblViewLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblViewLogo.Name = "lblViewLogo";
            this.lblViewLogo.Size = new System.Drawing.Size(349, 40);
            this.lblViewLogo.TabIndex = 62;
            this.lblViewLogo.Text = "GROUP EVALUATIONS MENU";
            // 
            // pbCloseButton2
            // 
            this.pbCloseButton2.BackColor = System.Drawing.Color.Transparent;
            this.pbCloseButton2.Image = global::DBProjectA.Properties.Resources.close_window;
            this.pbCloseButton2.Location = new System.Drawing.Point(660, 4);
            this.pbCloseButton2.Margin = new System.Windows.Forms.Padding(4);
            this.pbCloseButton2.Name = "pbCloseButton2";
            this.pbCloseButton2.Size = new System.Drawing.Size(52, 47);
            this.pbCloseButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCloseButton2.TabIndex = 63;
            this.pbCloseButton2.TabStop = false;
            this.pbCloseButton2.Click += new System.EventHandler(this.pbCloseButton2_Click);
            // 
            // GroupEvaluationsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(715, 466);
            this.Controls.Add(this.ViewAdvBtn);
            this.Controls.Add(this.BtnMarkEvaluations);
            this.Controls.Add(this.pbCloseButton2);
            this.Controls.Add(this.lblViewLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GroupEvaluationsMenu";
            this.Text = "GroupEvaluationsMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pbCloseButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ViewAdvBtn;
        private System.Windows.Forms.Button BtnMarkEvaluations;
        private System.Windows.Forms.PictureBox pbCloseButton2;
        private System.Windows.Forms.Label lblViewLogo;
    }
}