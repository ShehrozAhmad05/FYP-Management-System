﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class EditProject : Form
    {

        Project project;
        ProjectDL projectDL;
        public event EventHandler onSuccessUpdate;
        public EditProject(Project project)
        {
            InitializeComponent();
            projectDL = new ProjectDL();
            this.project = project;
            txtDescription.Text = project.Description;
            txtTitle.Text = project.Title;
        }

        private void pbCloseButton2_Click(object sender, EventArgs e)
        {
            ViewProject viewProject = new ViewProject();
            this.Close();
            viewProject.Close();

        }

        private void EditProject_Load(object sender, EventArgs e)
        {

        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[2];
            textBoxes[0] = txtTitle;
            textBoxes[1] = txtDescription;

            project.Title = txtTitle.Text;
            project.Description = txtDescription.Text;
            if (projectDL.update(project))
            {
                MessageBox.Show("Record Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                onSuccessUpdate?.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill the correct information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
