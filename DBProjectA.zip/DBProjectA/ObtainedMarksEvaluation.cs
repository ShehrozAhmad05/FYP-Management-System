﻿using DBProjectA.BL;
using DBProjectA.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DBProjectA
{
    public partial class ObtainedMarksEvaluation : Form
    {
        string groupId;
        string evaluationId;
        GroupEvaluationDL groupEvaluationDL;
        public event EventHandler onSuccess;

        public ObtainedMarksEvaluation(string groupId, string evaluationId, string totalMarks, string weightage)
        {
            InitializeComponent();
            this.txtTotalMarks.Text = totalMarks;
            this.txtWeightage.Text = weightage;
            this.txtTotalMarks.ReadOnly = true;
            this.txtWeightage.ReadOnly = true;
            this.evaluationId = evaluationId;
            this.groupId = groupId;
            groupEvaluationDL = new GroupEvaluationDL();
        }

        private void ObtainedMarksEvaluation_Load(object sender, EventArgs e)
        {

        }

        private void Evaluatebtn_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = new TextBox[3];
            textBoxes[0] = txtObtainedMarks;

            if (int.Parse(txtObtainedMarks.Text) <= int.Parse(txtTotalMarks.Text))
            {
                DateTime evaluationDate = new DateTime();
                evaluationDate = DateTime.Now;
                GroupEvaluation groupEvaluation = new GroupEvaluation(groupId, evaluationId, txtObtainedMarks.Text, evaluationDate.ToString());
                if (!groupEvaluationDL.insert(groupEvaluation))
                {
                    MessageBox.Show("Cannot Insert Data.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Data has been successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    onSuccess?.Invoke(this, null);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Obtained Marks Must Be Smaller Than Total Marks.", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
