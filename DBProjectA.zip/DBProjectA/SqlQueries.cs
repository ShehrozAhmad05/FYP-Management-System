﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public static class SqlQueries
    {
        public static SqlConnection con = Configuration.getInstance().getConnection();


        // INSERT QUERIES..............................................

        public static bool insertProjectAdvisor(string advisorId, string projectId, string role, string date)
        {
            int roleId = getAdvisorRole(role);
            if (roleId == -1)
                return false;
            try
            {

                SqlCommand cmd = new SqlCommand("insert into ProjectAdvisor values(" +
                                            "@advisorId ,@projectId ,@role , @date )", con);
                cmd.Parameters.AddWithValue("@advisorId", advisorId);
                cmd.Parameters.AddWithValue("@projectId", projectId);
                cmd.Parameters.AddWithValue("@role", roleId);
                cmd.Parameters.AddWithValue("@date", date);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool fillDesignationsCBX(ComboBox cbx)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select value from lookup where Category = 'DESIGNATION'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                List<string> designations = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    designations.Add(dt.Rows[i][0].ToString());
                }
                cbx.DataSource = designations;
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
        }

        private static int getAdvisorRole(string role)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select id from Lookup where  value = @role", con);
                cmd.Parameters.AddWithValue("@role", role);
                int id = int.Parse(cmd.ExecuteScalar().ToString());
                return id;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public static bool fillManageGroupStudentDGV(DataGridView DGV, string groupId)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select StudentId , FirstName , LastName , [Status] from GroupStudent g join Person p on p.Id = g.StudentId where GroupId = @groupId", con);
                cmd.Parameters.AddWithValue("@groupId", groupId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dt.Columns.Add("isActive", typeof(bool));
                dt.Columns.Add("isSelected", typeof(bool));
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i]["isSelected"] = true;
                    if (int.Parse(dt.Rows[i].ItemArray[3].ToString()) == 3)
                        dt.Rows[i]["isActive"] = true;

                }
                dt.Columns.RemoveAt(3);
                DGV.DataSource = dt;
                DGV.ReadOnly = false;
                DGV.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopLeft;
                DGV.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopLeft;
                DGV.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.TopLeft;
                DGV.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                DGV.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                foreach (DataGridViewColumn column in DGV.Columns)
                {
                    column.ReadOnly = true;
                }
                DGV.Columns[3].ReadOnly = false;
                DGV.Columns[4].ReadOnly = false;
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public static bool updateGroupStudentStatus(bool statusBool, string sid)
        {
            string statusStr = "";
            if (statusBool)
                statusStr = "Active";
            else
                statusStr = "InActive";
            try
            {
                int status = getStatus(statusStr);
                SqlCommand cmd = new SqlCommand("update GroupStudent set Status = @status where StudentId = @sid", con);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@sid", sid);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static int getStatus(string status)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select id  from Lookup where Value = @status", con);
                cmd.Parameters.AddWithValue("@status", status);
                int designationId = int.Parse(cmd.ExecuteScalar().ToString());
                return designationId;
            }
            catch (SqlException ex)
            {
                return -1;
            }
        }
    }
}
