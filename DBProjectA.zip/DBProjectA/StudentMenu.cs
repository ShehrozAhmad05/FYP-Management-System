﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProjectA
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        private void Insertbutton_Click(object sender, EventArgs e)
        {
            InsertForm insertForm = new InsertForm();
            this.Hide();
            insertForm.Show();
        }

        private void Editbutton_Click(object sender, EventArgs e)
        {

        }

        private void ViewButton_Click(object sender, EventArgs e)
        {
            ViewForm viewForm = new ViewForm();
            this.Hide();
            viewForm.Show();

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            SystemMenu menu = new SystemMenu();
            this.Close();
            menu.Show();
        }
    }
}
